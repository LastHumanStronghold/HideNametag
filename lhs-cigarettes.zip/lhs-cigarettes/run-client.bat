@echo off
setlocal
cd /d "%~dp0"
call gradlew.bat runClient --no-daemon
pause
