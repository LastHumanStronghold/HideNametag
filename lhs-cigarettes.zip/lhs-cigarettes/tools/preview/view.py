import sys, subprocess, math
import numpy as np
from PIL import Image
G="/home/claude/lhs-cigarettes/src/main/resources/assets/lhscigs/geo/cigarettes_geo.json"
T=np.array(Image.open("/home/claude/lhs-cigarettes/src/main/resources/assets/lhscigs/textures/item/cigarettes_uv.png").convert("RGBA"))
def quads(bones):
    out=subprocess.run(["java","-cp","out:/opt/gradle/lib/gson-2.10.jar","Dump",G,bones],capture_output=True,text=True).stdout
    q=[]
    for l in out.strip().split("\n"):
        a=np.array(l.split(),float).reshape(4,5); q.append(a)
    return q
def render(bones,yaw,pitch,fn,S=420):
    q=quads(bones)
    pts=np.vstack([a[:,:3] for a in q]); c=(pts.min(0)+pts.max(0))/2; ext=(pts.max(0)-pts.min(0)).max()
    cy,sy=math.cos(math.radians(yaw)),math.sin(math.radians(yaw)); cp,sp=math.cos(math.radians(pitch)),math.sin(math.radians(pitch))
    Ry=np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]]); Rx=np.array([[1,0,0],[0,cp,-sp],[0,sp,cp]])
    img=np.zeros((S,S,4),np.uint8); img[...]=(40,40,50,255); zb=np.full((S,S),1e9)
    for a in q:
        p=(a[:,:3]-c)@Ry.T@Rx.T
        sx=S/2+p[:,0]/ext*S*0.8; sya=S/2-p[:,1]/ext*S*0.8; z=-p[:,2]
        for tri in ((0,1,2),(0,2,3)):
            i=list(tri); x=sx[i]; y=sya[i]
            x0,x1=int(max(0,x.min())),int(min(S-1,x.max()+1)); y0,y1=int(max(0,y.min())),int(min(S-1,y.max()+1))
            d=(y[1]-y[2])*(x[0]-x[2])+(x[2]-x[1])*(y[0]-y[2])
            if abs(d)<1e-9: continue
            for py in range(y0,y1+1):
                for px in range(x0,x1+1):
                    l0=((y[1]-y[2])*(px-x[2])+(x[2]-x[1])*(py-y[2]))/d
                    l1=((y[2]-y[0])*(px-x[2])+(x[0]-x[2])*(py-y[2]))/d
                    l2=1-l0-l1
                    if l0<-1e-4 or l1<-1e-4 or l2<-1e-4: continue
                    zz=l0*z[i[0]]+l1*z[i[1]]+l2*z[i[2]]
                    if zz>=zb[py,px]: continue
                    u=l0*a[i[0],3]+l1*a[i[1],3]+l2*a[i[2],3]; v=l0*a[i[0],4]+l1*a[i[1],4]+l2*a[i[2],4]
                    col=T[min(255,max(0,int(v*256))),min(255,max(0,int(u*256)))]
                    if col[3]<128: continue
                    zb[py,px]=zz; img[py,px]=col
    Image.fromarray(img).save(fn)
PACK="body,cap,cig,cig2,cig7,cig4,cig5,cig6,burn,burn2,burn7,burn4,burn5,burn6"
if __name__=="__main__":
    render(PACK,float(sys.argv[1]),float(sys.argv[2]),sys.argv[3])
