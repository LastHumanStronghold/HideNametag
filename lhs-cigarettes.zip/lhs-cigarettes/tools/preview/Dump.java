import com.mainlhs.cigs.geo.BedrockModel;
import java.io.*;
import java.util.*;
public class Dump {
  public static void main(String[] a) throws Exception {
    BedrockModel m = BedrockModel.parse(new FileReader(a[0]));
    List<String> bones = Arrays.asList(a[1].split(","));
    StringBuilder sb = new StringBuilder();
    for (BedrockModel.Quad q : m.quads(bones)) {
      for (int i=0;i<4;i++) for (int j=0;j<5;j++) sb.append(q.v[i][j]).append(' ');
      sb.append('\n');
    }
    System.out.print(sb);
  }
}
