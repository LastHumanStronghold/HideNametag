@echo off
setlocal
cd /d "%~dp0"
echo === LHS Cigarettes: build ===
where java >nul 2>nul || (echo [ERROR] Java not found. Install JDK 17 and set JAVA_HOME. & pause & exit /b 1)
call gradlew.bat clean build --no-daemon
if errorlevel 1 (
  echo.
  echo [ERROR] Build failed. Send me the text above.
  pause
  exit /b 1
)
echo.
echo Done. Jar: %~dp0build\libs\LHS-Cigarettes-1.0.0.jar
echo Put it into mods\ on the server AND on every client.
pause
