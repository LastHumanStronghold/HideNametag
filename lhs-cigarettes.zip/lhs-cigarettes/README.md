# LHS Cigarettes: third-person smoking for the TACZ cigarettes (Forge 1.20.1)

First person stays 100% TACZ (the addon's own 9.5 s animation, hands, sounds). This mod adds what TACZ lacks:
**what other players see in third person**, plus a creative tab for the item.

> **Status: not compiled or tested in-game** (no Forge jars/network where I wrote it). Expect a name fix or two
> on the first build and some tuning of angles.

## Build (Windows)
1. JDK 17. 2. Double-click `build.bat` (first run downloads Gradle 8.8, Forge, Minecraft). 3. Jar: `build\libs\LHS-Cigarettes-1.0.0.jar`.
`run-client.bat` / `run-server.bat` start dev instances. Put the jar on the server **and every client**, next to TACZ,
LR Tactical and the Stims and Stuffs pack.

## What it does
- Detects a player using the item `lrtactical:consumable` whose NBT mentions `stimshot:cigars` (key-independent).
- Arm pose (`client/SmokePose`): cigarette hand goes to the mouth, other hand raises the lighter, head tilts back.
- 3D cigarette + ember and lighter + flame (`client/SmokeLayer`) drawn from the addon's own model
  (`geo/BedrockModel` reads the Bedrock geo file; verified by rendering it to PNG in `tools/preview`).
- Timeline (`Smoking.java`) copied from the addon's "use" animation: rustle 0.27 s, cigarette out 0.65, lighter 1.1, fire 1.46,
  drag 1.6, lighter closed 3.5, exhale 4.79, 2nd drag 6.0, cigarette gone 9.0. Smoke particles at the same moments.
- Sounds (mono copies of the addon's) for **other** players at those moments. If you already hear them doubled,
  set `PLAY_SOUNDS_FOR_OTHERS = false` in `ClientSetup`.
- Creative tab **LHS Cigarettes**: copies the stack from LR Tactical's own tab; if not found it builds
  `{ConsumableId:"stimshot:cigars"}` (change `CigStacks.FALLBACK_NBT_KEY` if the key is different; check with
  `/data get entity @s SelectedItem` while holding one).

## Assumptions to verify
- TACZ's "toggle" use is a normal vanilla item use (`isUsingItem`) so it is synced to other clients. If other people
  see nothing, tell me and I'll hook TACZ's own state instead.
- Lighter orientation (`SmokeLayer`, the `ZP 90` rotation) and arm angles (`SmokePose`) are first guesses.

## Putting it inside LHSMENU
No LHSMENU source exists, so it ships as a companion jar. To merge: copy the package, call `CigsMod.register(modBus)` from
`MainLHS`, set `MOD_ID` to `mainlhs`, move `assets/lhscigs/*` to `assets/mainlhs/*`.

Addon licence is "All Rights Reserved": get the author's permission before publishing publicly.
