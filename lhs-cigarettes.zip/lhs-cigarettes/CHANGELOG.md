# Changelog
## 1.0.0
- Third-person smoking for TACZ cigarettes (timeline from the addon's animation), creative tab.
