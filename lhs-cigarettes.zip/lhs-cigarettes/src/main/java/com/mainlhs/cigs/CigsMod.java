package com.mainlhs.cigs;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Third-person smoking for the TACZ "Stims and Stuffs" cigarettes (item lrtactical:consumable, id stimshot:cigars)
 * plus a creative tab listing them. First-person is left entirely to TACZ.
 *
 * To merge into LHSMENU: copy this package, call {@link #register(IEventBus)} from MainLHS's constructor,
 * set MOD_ID to "mainlhs" and move assets/lhscigs/* to assets/mainlhs/*.
 */
@Mod(CigsMod.MOD_ID)
public class CigsMod {
    public static final String MOD_ID = "lhscigs";

    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final Map<String, RegistryObject<SoundEvent>> SOUND = new LinkedHashMap<>();

    static {
        for (String n : new String[]{"box_rustle", "box_rustle_2", "lighter_pullout", "lighter_open", "lighter_fire",
                "drag_1", "drag_2", "hand_move", "lighter_close", "exhale"}) {
            SOUND.put(n, SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MOD_ID, n))));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("cigarettes",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.lhscigs"))
                    .icon(CigStacks::icon)
                    .displayItems((params, out) -> CigStacks.find().forEach(out::accept))
                    .build());

    public CigsMod() {
        register(FMLJavaModLoadingContext.get().getModEventBus());
    }

    public static void register(IEventBus bus) {
        SOUNDS.register(bus);
        TABS.register(bus);
    }
}
