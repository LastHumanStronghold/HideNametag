package com.mainlhs.cigs;

/**
 * Third-person timeline, taken from the addon's own 9.5 s "use" animation (assets/stimshot/animations/consumable/
 * cigars.animation.json). 1 s = 20 ticks. TACZ plays the first-person version; this drives what other people see.
 *
 *  0.27 box rustle | 0.65 cigarette out | 1.10 lighter out | 1.42 open | 1.46 fire | 1.60 drag
 *  3.23 hand move  | 3.50 lighter close | 4.79 exhale | 6.00 second drag | 9.0 cigarette gone
 */
public final class Smoking {
    private Smoking() {}

    public record Event(int tick, String sound, int smoke) {}

    public static final Event[] EVENTS = {
            new Event(5, "box_rustle", 0),
            new Event(12, "box_rustle_2", 0),
            new Event(22, "lighter_pullout", 0),
            new Event(28, "lighter_open", 0),
            new Event(29, "lighter_fire", 0),
            new Event(32, "drag_1", 0),
            new Event(65, "hand_move", 0),
            new Event(70, "lighter_close", 0),
            new Event(96, "exhale", 18),
            new Event(120, "drag_2", 0),
            new Event(142, "", 8),
    };

    /** Cigarette in the fingers (0.65 s .. 9.0 s). */
    public static boolean cigVisible(float t) { return t >= 13 && t < 180; }
    /** Lighter in the other hand (1.10 s .. 3.5 s). */
    public static boolean lighterVisible(float t) { return t >= 22 && t < 70; }
    /** Flame (1.46 s .. 3.3 s). */
    public static boolean flameVisible(float t) { return t >= 29 && t < 66; }
    public static boolean usingLighterArm(float t) { return t >= 16 && t < 76; }

    // keyframes: {tick, lift}; lift 0 = arm relaxed, 1 = hand at the mouth
    private static final float[][] CIG = {
            {0, .35f}, {12, .35f}, {22, 1}, {64, 1}, {72, .5f}, {90, .5f}, {96, .15f}, {112, .15f},
            {122, 1}, {140, 1}, {152, .35f}, {176, .35f}, {182, 0}, {400, 0}};
    private static final float[][] LIGHTER = {{0, 0}, {16, 0}, {26, 1}, {64, 1}, {76, 0}, {400, 0}};

    public static float cigLift(float t) { return sample(CIG, t); }
    public static float lighterLift(float t) { return sample(LIGHTER, t); }

    private static float sample(float[][] k, float t) {
        if (t <= k[0][0]) return k[0][1];
        for (int i = 1; i < k.length; i++) {
            if (t <= k[i][0]) {
                float f = (t - k[i - 1][0]) / (k[i][0] - k[i - 1][0]);
                return k[i - 1][1] + (k[i][1] - k[i - 1][1]) * smooth(f);
            }
        }
        return k[k.length - 1][1];
    }

    public static float smooth(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return x * x * (3f - 2f * x);
    }
}
