package com.mainlhs.cigs.client;

import com.mainlhs.cigs.CigsMod;
import com.mainlhs.cigs.geo.BedrockModel;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/** Loads the addon's Bedrock model once and draws parts of it. */
public final class CigGeo {
    private CigGeo() {}

    public static final ResourceLocation GEO = new ResourceLocation(CigsMod.MOD_ID, "geo/cigarettes_geo.json");
    public static final ResourceLocation TEX = new ResourceLocation(CigsMod.MOD_ID, "textures/item/cigarettes_uv.png");

    public static final List<String> PACK = List.of("body", "cap", "cig", "cig2", "cig7", "cig4", "cig5", "cig6",
            "burn", "burn2", "burn7", "burn4", "burn5", "burn6");
    public static final List<String> SINGLE = List.of("pull_cig", "group");
    public static final List<String> EMBER = List.of("burn9");
    public static final List<String> LIGHTER = List.of("lighter", "head", "switch");
    public static final List<String> FLAME = List.of("flame", "flame2", "flame5", "flame6");

    private static BedrockModel model;
    private static final java.util.Map<List<String>, Part> PARTS = new java.util.HashMap<>();

    /** Quads re-centred on the middle of their bounding box. */
    public record Part(List<BedrockModel.Quad> quads) {}

    public static void clear() {
        model = null;
        PARTS.clear();
    }

    public static Part part(List<String> bones) {
        return PARTS.computeIfAbsent(bones, CigGeo::build);
    }

    private static Part build(List<String> bones) {
        if (model == null) {
            try (Reader r = Minecraft.getInstance().getResourceManager().getResourceOrThrow(GEO).openAsReader()) {
                model = BedrockModel.parse(r);
            } catch (Exception e) {
                throw new IllegalStateException("Cannot load " + GEO, e);
            }
        }
        // centre on the whole pack/cigarette group so a single piece keeps its place relative to its siblings
        List<BedrockModel.Quad> all = model.quads(bones);
        return new Part(all);
    }

    /** Centre of the quads of the given bones (used to recentre). */
    public static float[] centre(List<String> bones) {
        float[] mn = {1e9f, 1e9f, 1e9f}, mx = {-1e9f, -1e9f, -1e9f};
        for (BedrockModel.Quad q : part(bones).quads()) {
            for (float[] v : q.v) {
                for (int i = 0; i < 3; i++) { mn[i] = Math.min(mn[i], v[i]); mx[i] = Math.max(mx[i], v[i]); }
            }
        }
        return new float[]{(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2};
    }

    /** Draws the part with the current pose, translated by -centre (so it rotates around its middle). */
    public static void draw(PoseStack ps, net.minecraft.client.renderer.MultiBufferSource buffers,
                            List<String> bones, float[] centre, int light, int overlay) {
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEX));
        PoseStack.Pose pose = ps.last();
        for (BedrockModel.Quad q : part(bones).quads()) {
            for (float[] v : q.v) {
                vc.vertex(pose.pose(), v[0] - centre[0], v[1] - centre[1], v[2] - centre[2])
                        .color(255, 255, 255, 255)
                        .uv(v[3], v[4])
                        .overlayCoords(overlay)
                        .uv2(light)
                        .normal(pose.normal(), q.n[0], q.n[1], q.n[2])
                        .endVertex();
            }
        }
    }
}
