package com.mainlhs.cigs.geo;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.Reader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal Bedrock ".geo.json" reader (boxes only, no poly_mesh). Pure Java, no Minecraft classes,
 * so the geometry maths can be unit-tested. Output quads are in block units (1/16 of the file units),
 * Y up, same orientation conventions as vanilla block models (north = -Z).
 */
public final class BedrockModel {
    /** 4 vertices, each {x,y,z,u,v} (u,v already divided by texture size), plus normal. */
    public static final class Quad {
        public final float[][] v = new float[4][5];
        public final float[] n = new float[3];
    }

    private static final class Cube {
        double[] origin, size, rot, pivot;
        double inflate;
        // per face: {u0, v0, u1, v1} in pixels, order N,E,S,W,U,D
        double[][] faceUv = new double[6][];
    }

    private static final class Bone {
        String name, parent;
        double[] pivot = {0, 0, 0}, rot = {0, 0, 0};
        List<Cube> cubes = new ArrayList<>();
    }

    private final Map<String, Bone> bones = new LinkedHashMap<>();
    private double texW = 16, texH = 16;

    public static BedrockModel parse(Reader reader) {
        JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
        JsonObject geo = root.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();
        JsonObject desc = geo.getAsJsonObject("description");
        BedrockModel m = new BedrockModel();
        m.texW = desc.get("texture_width").getAsDouble();
        m.texH = desc.get("texture_height").getAsDouble();
        for (JsonElement be : geo.getAsJsonArray("bones")) {
            JsonObject bj = be.getAsJsonObject();
            Bone b = new Bone();
            b.name = bj.get("name").getAsString();
            b.parent = bj.has("parent") ? bj.get("parent").getAsString() : null;
            if (bj.has("pivot")) b.pivot = arr(bj.getAsJsonArray("pivot"));
            if (bj.has("rotation")) b.rot = arr(bj.getAsJsonArray("rotation"));
            if (bj.has("cubes")) {
                for (JsonElement ce : bj.getAsJsonArray("cubes")) b.cubes.add(parseCube(ce.getAsJsonObject()));
            }
            m.bones.put(b.name, b);
        }
        return m;
    }

    private static double[] arr(JsonArray a) {
        double[] r = new double[a.size()];
        for (int i = 0; i < r.length; i++) r[i] = a.get(i).getAsDouble();
        return r;
    }

    private static Cube parseCube(JsonObject cj) {
        Cube c = new Cube();
        c.origin = arr(cj.getAsJsonArray("origin"));
        c.size = arr(cj.getAsJsonArray("size"));
        c.rot = cj.has("rotation") ? arr(cj.getAsJsonArray("rotation")) : null;
        c.pivot = cj.has("pivot") ? arr(cj.getAsJsonArray("pivot")) : null;
        c.inflate = cj.has("inflate") ? cj.get("inflate").getAsDouble() : 0;
        double w = c.size[0], h = c.size[1], d = c.size[2];
        JsonElement uv = cj.get("uv");
        if (uv != null && uv.isJsonArray()) {
            double u = uv.getAsJsonArray().get(0).getAsDouble(), v = uv.getAsJsonArray().get(1).getAsDouble();
            c.faceUv[0] = new double[]{u + d, v + d, u + d + w, v + d + h};               // north
            c.faceUv[1] = new double[]{u, v + d, u + d, v + d + h};                       // east
            c.faceUv[2] = new double[]{u + d + w + d, v + d, u + d + w + d + w, v + d + h}; // south
            c.faceUv[3] = new double[]{u + d + w, v + d, u + d + w + d, v + d + h};       // west
            c.faceUv[4] = new double[]{u + d, v, u + d + w, v + d};                       // up
            c.faceUv[5] = new double[]{u + d + w, v, u + d + w + w, v + d};               // down
        } else if (uv != null && uv.isJsonObject()) {
            String[] names = {"north", "east", "south", "west", "up", "down"};
            JsonObject o = uv.getAsJsonObject();
            for (int i = 0; i < 6; i++) {
                if (!o.has(names[i])) continue;
                JsonObject f = o.getAsJsonObject(names[i]);
                double u = f.getAsJsonArray("uv").get(0).getAsDouble(), v = f.getAsJsonArray("uv").get(1).getAsDouble();
                double su = f.getAsJsonArray("uv_size").get(0).getAsDouble(), sv = f.getAsJsonArray("uv_size").get(1).getAsDouble();
                c.faceUv[i] = new double[]{u, v, u + su, v + sv};
            }
        }
        // A cube with a single textured face is a decal (e.g. the label on the pack). It sits flush with the
        // wall in the file, so nudge it outwards to avoid being hidden / z-fighting.
        int faces = 0, only = -1;
        for (int i = 0; i < 6; i++) if (c.faceUv[i] != null) { faces++; only = i; }
        if (faces == 1) {
            double e = -0.4; // empirically: moves the label out of the wall after the box bone's -90 deg turn
            switch (only) {
                case 0 -> c.origin[2] -= e;
                case 1 -> c.origin[0] += e;
                case 2 -> c.origin[2] += e;
                case 3 -> c.origin[0] -= e;
                case 4 -> c.origin[1] += e;
                default -> c.origin[1] -= e;
            }
        }
        return c;
    }

    public boolean hasBone(String name) {
        return bones.containsKey(name);
    }

    /** Sign convention of the rotation angles; verified against the addon's own preview (see tools/preview). */
    private static final double RX = 1, RY = -1, RZ = -1;

    /** All quads of the given bones (animation offsets are not applied: this is the rest pose). */
    public List<Quad> quads(Collection<String> include) {
        List<Quad> out = new ArrayList<>();
        for (String name : include) {
            Bone b = bones.get(name);
            if (b == null) continue;
            for (Cube c : b.cubes) addCube(out, b, c);
        }
        return out;
    }

    private void addCube(List<Quad> out, Bone bone, Cube c) {
        double g = c.inflate;
        double x0 = c.origin[0] - g, y0 = c.origin[1] - g, z0 = c.origin[2] - g;
        double x1 = c.origin[0] + c.size[0] + g, y1 = c.origin[1] + c.size[1] + g, z1 = c.origin[2] + c.size[2] + g;
        // corners per face: TL, TR, BR, BL  (see texture orientation in comments of parseCube)
        double[][][] face = {
            {{x1, y1, z0}, {x0, y1, z0}, {x0, y0, z0}, {x1, y0, z0}},   // north
            {{x1, y1, z0}, {x1, y1, z1}, {x1, y0, z1}, {x1, y0, z0}},   // east
            {{x0, y1, z1}, {x1, y1, z1}, {x1, y0, z1}, {x0, y0, z1}},   // south
            {{x0, y1, z1}, {x0, y1, z0}, {x0, y0, z0}, {x0, y0, z1}},   // west
            {{x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}},   // up
            {{x0, y0, z1}, {x1, y0, z1}, {x1, y0, z0}, {x0, y0, z0}},   // down
        };
        double[][] normal = {{0, 0, -1}, {1, 0, 0}, {0, 0, 1}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}};
        for (int f = 0; f < 6; f++) {
            if (c.faceUv[f] == null) continue;
            double[] uv = c.faceUv[f];
            double[][] tex = {{uv[0], uv[1]}, {uv[2], uv[1]}, {uv[2], uv[3]}, {uv[0], uv[3]}};
            Quad q = new Quad();
            for (int i = 0; i < 4; i++) {
                double[] p = face[f][i].clone();
                if (c.rot != null) rotate(p, c.pivot != null ? c.pivot : new double[]{0, 0, 0}, c.rot);
                for (Bone b = bone; b != null; b = b.parent == null ? null : bones.get(b.parent)) rotate(p, b.pivot, b.rot);
                q.v[i][0] = (float) (p[0] / 16.0);
                q.v[i][1] = (float) (p[1] / 16.0);
                q.v[i][2] = (float) (p[2] / 16.0);
                q.v[i][3] = (float) (tex[i][0] / texW);
                q.v[i][4] = (float) (tex[i][1] / texH);
            }
            // normal from the transformed vertices
            float ax = q.v[1][0] - q.v[0][0], ay = q.v[1][1] - q.v[0][1], az = q.v[1][2] - q.v[0][2];
            float bx = q.v[3][0] - q.v[0][0], by = q.v[3][1] - q.v[0][1], bz = q.v[3][2] - q.v[0][2];
            float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
            float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (len < 1e-9f) { nx = (float) normal[f][0]; ny = (float) normal[f][1]; nz = (float) normal[f][2]; len = 1; }
            q.n[0] = nx / len; q.n[1] = ny / len; q.n[2] = nz / len;
            out.add(q);
        }
    }

    /** p = pivot + Rz*Ry*Rx * (p - pivot), angles in degrees from the file. */
    private static void rotate(double[] p, double[] pivot, double[] rot) {
        if (rot == null || (rot[0] == 0 && rot[1] == 0 && rot[2] == 0)) return;
        double ax = Math.toRadians(rot[0] * RX), ay = Math.toRadians(rot[1] * RY), az = Math.toRadians(rot[2] * RZ);
        double x = p[0] - pivot[0], y = p[1] - pivot[1], z = p[2] - pivot[2];
        double c = Math.cos(ax), s = Math.sin(ax);
        double y1 = y * c - z * s, z1 = y * s + z * c; y = y1; z = z1;
        c = Math.cos(ay); s = Math.sin(ay);
        double x2 = x * c + z * s, z2 = -x * s + z * c; x = x2; z = z2;
        c = Math.cos(az); s = Math.sin(az);
        double x3 = x * c - y * s, y3 = x * s + y * c; x = x3; y = y3;
        p[0] = pivot[0] + x; p[1] = pivot[1] + y; p[2] = pivot[2] + z;
    }
}
