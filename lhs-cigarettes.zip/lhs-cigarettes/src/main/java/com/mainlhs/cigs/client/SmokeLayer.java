package com.mainlhs.cigs.client;

import com.mainlhs.cigs.CigStacks;
import com.mainlhs.cigs.Smoking;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;

/**
 * Draws the addon's 3D cigarette (with ember) in one hand and its lighter (with flame) in the other, in the
 * hand frame vanilla uses for held items, so they follow SmokePose to the mouth. Runs on every client for every
 * visible player, which is why other people see it.
 */
public class SmokeLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public SmokeLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partial, float age, float yaw, float pitch) {
        if (!CigStacks.isSmoking(p)) return;
        float t = p.getTicksUsingItem() + partial;
        HumanoidArm cigArm = p.getUsedItemHand() == InteractionHand.MAIN_HAND ? p.getMainArm() : p.getMainArm().getOpposite();

        if (Smoking.cigVisible(t)) {
            handFrame(ps, cigArm);
            ps.scale(1.1f, 1.1f, 1.1f);
            float[] c = CigGeo.centre(CigGeo.SINGLE);
            CigGeo.draw(ps, buffers, CigGeo.SINGLE, c, light, OverlayTexture.NO_OVERLAY);
            CigGeo.draw(ps, buffers, CigGeo.EMBER, c, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
            ps.popPose();
        }
        if (Smoking.lighterVisible(t)) {
            handFrame(ps, cigArm.getOpposite());
            ps.scale(1.0f, 1.0f, 1.0f);
            ps.mulPose(Axis.ZP.rotationDegrees(90));     // lighter lies on its side in the file; stand it up
            float[] c = CigGeo.centre(CigGeo.LIGHTER);
            CigGeo.draw(ps, buffers, CigGeo.LIGHTER, c, light, OverlayTexture.NO_OVERLAY);
            if (Smoking.flameVisible(t)) {
                CigGeo.draw(ps, buffers, CigGeo.FLAME, c, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
            }
            ps.popPose();
        }
    }

    /** Same transform ItemInHandLayer uses; leaves one pose pushed. */
    private void handFrame(PoseStack ps, HumanoidArm arm) {
        ps.pushPose();
        getParentModel().translateToHand(arm, ps);
        ps.mulPose(Axis.XP.rotationDegrees(-90));
        ps.mulPose(Axis.YP.rotationDegrees(180));
        ps.translate((arm == HumanoidArm.LEFT ? -1 : 1) / 16f, 0.125f, -0.625f);
    }
}
