package com.mainlhs.cigs.client;

import com.mainlhs.cigs.Smoking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;

/**
 * Third-person arm poses. Vanilla syncs "is using item" to every nearby client, so every client can animate every
 * smoking player from LivingEntity#getTicksUsingItem. Tune the angles here if the hand misses the mouth.
 */
public final class SmokePose {
    private SmokePose() {}

    /** Hand holding the cigarette. */
    public static final HumanoidModel.ArmPose CIG = HumanoidModel.ArmPose.create("LHS_SMOKE", false,
            (model, entity, arm) -> apply(model, entity, arm, -0.75f, Smoking.cigLift(ticks(entity)), true));
    /** Other hand, holding the lighter. */
    public static final HumanoidModel.ArmPose LIGHTER = HumanoidModel.ArmPose.create("LHS_LIGHTER", false,
            (model, entity, arm) -> apply(model, entity, arm, 0.0f, Smoking.lighterLift(ticks(entity)), false));

    private static float ticks(LivingEntity e) {
        return e.getTicksUsingItem() + Minecraft.getInstance().getFrameTime();
    }

    private static void apply(HumanoidModel<?> model, LivingEntity e, HumanoidArm arm, float base, float lift, boolean head) {
        boolean right = arm == HumanoidArm.RIGHT;
        ModelPart part = right ? model.rightArm : model.leftArm;
        float side = right ? 1f : -1f;
        part.xRot = lerp(base, -2.45f, lift);
        part.yRot = side * lerp(-0.1f, -0.55f, lift);
        part.zRot = side * lerp(0.05f, 0.18f, lift);
        if (head) model.head.xRot -= 0.12f * Smoking.smooth(lift);   // slight head tilt back
    }

    private static float lerp(float a, float b, float f) {
        return a + (b - a) * f;
    }
}
