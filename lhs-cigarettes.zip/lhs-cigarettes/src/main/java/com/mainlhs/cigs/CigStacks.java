package com.mainlhs.cigs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/** Recognises / builds the TACZ (LR Tactical) consumable "stimshot:cigars" without depending on those mods at compile time. */
public final class CigStacks {
    private CigStacks() {}

    public static final String CONSUMABLE_ITEM = "lrtactical:consumable";
    public static final String CIG_ID = "stimshot:cigars";
    /** Only used if the cigarette stack can't be found in LR Tactical's own creative tab. Check with /data get. */
    public static final String FALLBACK_NBT_KEY = "ConsumableId";

    public static boolean isCig(ItemStack s) {
        if (s.isEmpty() || !s.hasTag()) return false;
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        return k != null && CONSUMABLE_ITEM.equals(k.toString()) && s.getTag().toString().contains(CIG_ID);
    }

    public static boolean isSmoking(Player p) {
        return p.isUsingItem() && isCig(p.getUseItem());
    }

    /** The cigarette stack(s) as LR Tactical itself lists them; falls back to a hand-made stack. */
    public static List<ItemStack> find() {
        List<ItemStack> out = new ArrayList<>();
        CreativeModeTab mine = CigsMod.TAB.isPresent() ? CigsMod.TAB.get() : null;
        for (CreativeModeTab tab : BuiltInRegistries.CREATIVE_MODE_TAB) {
            if (tab == mine) continue;
            for (ItemStack s : tab.getDisplayItems()) {
                if (isCig(s)) { out.add(s.copy()); return out; }
            }
        }
        Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(CONSUMABLE_ITEM));
        if (it != null && it != Items.AIR) {
            ItemStack st = new ItemStack(it);
            CompoundTag tag = new CompoundTag();
            tag.putString(FALLBACK_NBT_KEY, CIG_ID);
            st.setTag(tag);
            out.add(st);
        }
        return out;
    }

    public static ItemStack icon() {
        List<ItemStack> l = find();
        return l.isEmpty() ? new ItemStack(Items.FLINT_AND_STEEL) : l.get(0);
    }
}
