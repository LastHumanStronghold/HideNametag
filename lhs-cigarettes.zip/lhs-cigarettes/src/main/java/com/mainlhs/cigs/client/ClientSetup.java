package com.mainlhs.cigs.client;

import com.mainlhs.cigs.CigStacks;
import com.mainlhs.cigs.CigsMod;
import com.mainlhs.cigs.Smoking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class ClientSetup {
    private ClientSetup() {}

    /** TACZ plays the animation's sounds only for the smoker. Set to false if you hear doubled sounds. */
    public static final boolean PLAY_SOUNDS_FOR_OTHERS = true;

    @Mod.EventBusSubscriber(modid = CigsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent
        public static void addLayers(EntityRenderersEvent.AddLayers e) {
            for (String skin : e.getSkins()) {
                if (e.getSkin(skin) instanceof PlayerRenderer r) r.addLayer(new SmokeLayer(r));
            }
        }

        @SubscribeEvent
        public static void reload(RegisterClientReloadListenersEvent e) {
            e.registerReloadListener((net.minecraft.server.packs.resources.ResourceManagerReloadListener) rm -> CigGeo.clear());
        }
    }

    @Mod.EventBusSubscriber(modid = CigsMod.MOD_ID, value = Dist.CLIENT)
    public static final class ForgeBus {
        /** Runs after PlayerRenderer#setModelProperties, so our poses are not overwritten. */
        @SubscribeEvent
        public static void pose(RenderLivingEvent.Pre<?, ?> e) {
            if (!(e.getEntity() instanceof AbstractClientPlayer p) || !(e.getRenderer().getModel() instanceof PlayerModel<?> m)) return;
            if (!CigStacks.isSmoking(p)) return;
            float t = p.getTicksUsingItem();
            HumanoidArm cigArm = p.getUsedItemHand() == InteractionHand.MAIN_HAND ? p.getMainArm() : p.getMainArm().getOpposite();
            if (cigArm == HumanoidArm.RIGHT) m.rightArmPose = SmokePose.CIG; else m.leftArmPose = SmokePose.CIG;
            if (Smoking.usingLighterArm(t)) {
                if (cigArm == HumanoidArm.RIGHT) m.leftArmPose = SmokePose.LIGHTER; else m.rightArmPose = SmokePose.LIGHTER;
            }
        }

        @SubscribeEvent
        public static void tick(TickEvent.PlayerTickEvent e) {
            if (e.phase != TickEvent.Phase.END || !e.player.level().isClientSide) return;
            Player p = e.player;
            if (!CigStacks.isSmoking(p)) return;
            Minecraft mc = Minecraft.getInstance();
            boolean self = p == mc.player;
            int t = p.getTicksUsingItem();
            for (Smoking.Event ev : Smoking.EVENTS) {
                if (ev.tick() != t) continue;
                if (!self && PLAY_SOUNDS_FOR_OTHERS && !ev.sound().isEmpty()) {
                    p.level().playLocalSound(p.getX(), p.getEyeY(), p.getZ(), CigsMod.SOUND.get(ev.sound()).get(),
                            SoundSource.PLAYERS, 0.8f, 1f, false);
                }
                if (ev.smoke() > 0) puff(p, ev.smoke(), self && mc.options.getCameraType().isFirstPerson());
            }
            if (t > 40 && t < 170 && t % 14 == 0) puff(p, 1, self && mc.options.getCameraType().isFirstPerson());
        }

        private static void puff(Player p, int n, boolean skip) {
            if (skip) return;
            Vec3 pos = p.getEyePosition().add(p.getLookAngle().scale(0.35)).add(0, -0.12, 0);
            for (int i = 0; i < n; i++) {
                double r = p.getRandom().nextGaussian() * 0.01;
                p.level().addParticle(ParticleTypes.SMOKE, pos.x + r, pos.y, pos.z + r,
                        p.getLookAngle().x * 0.02, 0.01 + Math.abs(r), p.getLookAngle().z * 0.02);
            }
        }
    }
}
