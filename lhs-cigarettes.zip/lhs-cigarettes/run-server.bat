@echo off
setlocal
cd /d "%~dp0"
if not exist run mkdir run
echo eula=true> run\eula.txt
call gradlew.bat runServer --no-daemon
pause
