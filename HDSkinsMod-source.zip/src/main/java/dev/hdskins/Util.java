package dev.hdskins;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.regex.Pattern;

/** Мелкие общие помощники (без зависимостей от Minecraft). */
final class Util {
    static final Pattern HASH = Pattern.compile("[0-9a-f]{64}");

    private Util() {
    }

    static String sha256(byte[] data) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
