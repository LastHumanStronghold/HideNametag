package dev.hdskins;

import java.awt.image.BufferedImage;

/**
 * Перевод старого формата скина (64x32, у HD - ширина x ширина/2) в современный 64x64:
 * левые рука и нога получаются зеркальным копированием правых - так же, как это делает сама игра.
 */
final class LegacySkin {
    /** {x, y, dx, dy, ширина, высота} в системе координат 64x64; зеркалим по горизонтали. */
    private static final int[][] OPS = {
            {4, 16, 16, 32, 4, 4}, {8, 16, 16, 32, 4, 4},
            {0, 20, 24, 32, 4, 12}, {4, 20, 16, 32, 4, 12}, {8, 20, 8, 32, 4, 12}, {12, 20, 16, 32, 4, 12},
            {44, 16, -8, 32, 4, 4}, {48, 16, -8, 32, 4, 4},
            {40, 20, 0, 32, 4, 12}, {44, 20, -8, 32, 4, 12}, {48, 20, -16, 32, 4, 12}, {52, 20, -8, 32, 4, 12}
    };

    private LegacySkin() {
    }

    /** @param src изображение шириной 64*s и высотой 32*s */
    static BufferedImage convert(BufferedImage src) {
        int w = src.getWidth();
        int s = w / 64;
        BufferedImage out = new BufferedImage(w, w, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < src.getHeight(); y++) {
            for (int x = 0; x < w; x++) out.setRGB(x, y, src.getRGB(x, y));
        }
        for (int[] o : OPS) {
            int x = o[0] * s, y = o[1] * s, dx = o[2] * s, dy = o[3] * s, rw = o[4] * s, rh = o[5] * s;
            for (int i = 0; i < rh; i++) {
                for (int j = 0; j < rw; j++) {
                    out.setRGB(x + dx + (rw - 1 - j), y + dy + i, out.getRGB(x + j, y + i));
                }
            }
        }
        return out;
    }
}
