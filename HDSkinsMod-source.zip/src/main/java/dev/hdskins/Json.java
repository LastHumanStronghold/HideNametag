package dev.hdskins;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Маленький разборщик JSON (без внешних библиотек): объекты -> Map, массивы -> List, числа -> Double. */
final class Json {
    private static final int MAX_DEPTH = 64;

    private final String s;
    private int i;

    private Json(String s) {
        this.s = s;
    }

    static Object parse(String text) throws SkinException {
        Json j = new Json(text);
        try {
            j.ws();
            Object v = j.value(0);
            j.ws();
            if (j.i != j.s.length()) throw new SkinException("Некорректный JSON (лишние данные в конце).");
            return v;
        } catch (IndexOutOfBoundsException | NumberFormatException e) {
            throw new SkinException("Некорректный JSON.");
        }
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> obj(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    static List<Object> arr(Object o) {
        return o instanceof List ? (List<Object>) o : null;
    }

    static double num(Object o, double def) {
        return o instanceof Double d ? d : def;
    }

    static String str(Object o) {
        return o instanceof String t ? t : null;
    }

    /** Массив из n чисел или null. */
    static double[] nums(Object o, int n) {
        List<Object> a = arr(o);
        if (a == null || a.size() < n) return null;
        double[] r = new double[n];
        for (int k = 0; k < n; k++) {
            if (!(a.get(k) instanceof Double d)) return null;
            r[k] = d;
        }
        return r;
    }

    private void ws() {
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
    }

    private Object value(int depth) throws SkinException {
        if (depth > MAX_DEPTH) throw new SkinException("JSON слишком глубоко вложен.");
        char c = s.charAt(i);
        switch (c) {
            case '{': {
                i++;
                Map<String, Object> m = new LinkedHashMap<>();
                ws();
                if (s.charAt(i) == '}') {
                    i++;
                    return m;
                }
                while (true) {
                    ws();
                    String k = string();
                    ws();
                    expect(':');
                    ws();
                    m.put(k, value(depth + 1));
                    ws();
                    char d = s.charAt(i++);
                    if (d == '}') return m;
                    if (d != ',') throw new SkinException("Некорректный JSON.");
                }
            }
            case '[': {
                i++;
                List<Object> l = new ArrayList<>();
                ws();
                if (s.charAt(i) == ']') {
                    i++;
                    return l;
                }
                while (true) {
                    ws();
                    l.add(value(depth + 1));
                    ws();
                    char d = s.charAt(i++);
                    if (d == ']') return l;
                    if (d != ',') throw new SkinException("Некорректный JSON.");
                }
            }
            case '"':
                return string();
            case 't':
                lit("true");
                return Boolean.TRUE;
            case 'f':
                lit("false");
                return Boolean.FALSE;
            case 'n':
                lit("null");
                return null;
            default: {
                int st = i;
                while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
                if (st == i) throw new SkinException("Некорректный JSON.");
                return Double.parseDouble(s.substring(st, i));
            }
        }
    }

    private void expect(char c) throws SkinException {
        if (s.charAt(i++) != c) throw new SkinException("Некорректный JSON.");
    }

    private void lit(String w) throws SkinException {
        if (!s.startsWith(w, i)) throw new SkinException("Некорректный JSON.");
        i += w.length();
    }

    private String string() throws SkinException {
        expect('"');
        StringBuilder b = null;
        int st = i;
        while (true) {
            char c = s.charAt(i);
            if (c == '"') {
                String r = b == null ? s.substring(st, i) : b.append(s, st, i).toString();
                i++;
                return r;
            }
            if (c == '\\') {
                if (b == null) b = new StringBuilder();
                b.append(s, st, i);
                char e = s.charAt(i + 1);
                i += 2;
                switch (e) {
                    case 'n' -> b.append('\n');
                    case 't' -> b.append('\t');
                    case 'r' -> b.append('\r');
                    case 'b' -> b.append('\b');
                    case 'f' -> b.append('\f');
                    case 'u' -> {
                        b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                        i += 4;
                    }
                    default -> b.append(e);
                }
                st = i;
            } else {
                i++;
            }
        }
    }
}
