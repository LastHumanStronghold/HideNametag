package dev.hdskins;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.tree.LiteralCommandNode;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.GameProfileArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * /hdskin (алиас /skin).
 * Права: load/unload/model - оператор (уровень 2). apply/set/cape себе - все, но HD-скин себе - только оператор.
 * Любые действия над другими игроками - оператор.
 */
public final class SkinCommands {
    private static final SuggestionProvider<CommandSourceStack> SKINS =
            (c, b) -> SharedSuggestionProvider.suggest(visibleSkinNames(c.getSource()), b);
    private static final SuggestionProvider<CommandSourceStack> FILES =
            (c, b) -> SharedSuggestionProvider.suggest(
                    ServerEvents.store() == null ? List.<String>of() : ServerEvents.store().listFiles(), b);
    private static final SuggestionProvider<CommandSourceStack> BODIES =
            (c, b) -> SharedSuggestionProvider.suggest(
                    ServerEvents.store() == null ? List.<String>of()
                            : ServerEvents.store().listModels().stream().map(SkinStore.Model::name).toList(), b);
    private static final SuggestionProvider<CommandSourceStack> MODELS =
            (c, b) -> SharedSuggestionProvider.suggest(List.of("slim", "classic"), b);

    /** Запросы к Mojang делаем не в главном потоке сервера. */
    private static final ExecutorService FETCH_POOL = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "HDSkins-mojang");
        t.setDaemon(true);
        return t;
    });
    private static final Map<UUID, Long> SET_COOLDOWN = new ConcurrentHashMap<>();
    private static final long SET_COOLDOWN_MS = 15_000;

    private SkinCommands() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("hdskin")
                .then(Commands.literal("list").executes(SkinCommands::list))
                .then(Commands.literal("load").requires(SkinCommands::op)
                        .then(Commands.argument("file", StringArgumentType.word()).suggests(FILES)
                                .executes(c -> load(c, null))
                                .then(Commands.argument("model", StringArgumentType.word()).suggests(MODELS)
                                        .executes(c -> load(c, StringArgumentType.getString(c, "model"))))))
                .then(Commands.literal("unload").requires(SkinCommands::op)
                        .then(Commands.argument("skin", StringArgumentType.word()).suggests(SKINS)
                                .executes(SkinCommands::unload)))
                .then(Commands.literal("model").requires(SkinCommands::op)
                        .then(Commands.argument("skin", StringArgumentType.word()).suggests(SKINS)
                                .then(Commands.argument("model", StringArgumentType.word()).suggests(MODELS)
                                        .executes(SkinCommands::model))))
                .then(Commands.literal("apply")
                        .then(Commands.argument("skin", StringArgumentType.word()).suggests(SKINS)
                                .executes(c -> apply(c, null))
                                .then(Commands.argument("player", GameProfileArgument.gameProfile())
                                        .executes(c -> apply(c, GameProfileArgument.getGameProfiles(c, "player"))))))
                .then(Commands.literal("set")
                        .then(Commands.argument("nick", StringArgumentType.word())
                                .executes(c -> set(c, null))
                                .then(Commands.argument("player", GameProfileArgument.gameProfile())
                                        .executes(c -> set(c, GameProfileArgument.getGameProfiles(c, "player"))))))
                .then(Commands.literal("models").requires(SkinCommands::op).executes(SkinCommands::models))
                .then(Commands.literal("body").requires(SkinCommands::op)
                        .then(Commands.literal("off").executes(c -> bodyOff(c, null))
                                .then(Commands.argument("player", GameProfileArgument.gameProfile())
                                        .executes(c -> bodyOff(c, GameProfileArgument.getGameProfiles(c, "player")))))
                        .then(Commands.argument("model", StringArgumentType.word()).suggests(BODIES)
                                .executes(c -> body(c, null))
                                .then(Commands.argument("player", GameProfileArgument.gameProfile())
                                        .executes(c -> body(c, GameProfileArgument.getGameProfiles(c, "player"))))))
                .then(Commands.literal("bodyfix").requires(SkinCommands::op)
                        .then(Commands.argument("model", StringArgumentType.word()).suggests(BODIES)
                                .then(Commands.argument("rot", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(-360, 360))
                                        .executes(c -> bodyFix(c, 1, 0))
                                        .then(Commands.argument("scale", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.05, 20))
                                                .executes(c -> bodyFix(c, com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(c, "scale"), 0))
                                                .then(Commands.argument("y", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(-20, 20))
                                                        .executes(c -> bodyFix(c, com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(c, "scale"),
                                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(c, "y"))))))))
                .then(Commands.literal("cape")
                        .then(Commands.literal("on").executes(c -> cape(c, true, null))
                                .then(Commands.argument("player", GameProfileArgument.gameProfile())
                                        .executes(c -> cape(c, true, GameProfileArgument.getGameProfiles(c, "player")))))
                        .then(Commands.literal("off").executes(c -> cape(c, false, null))
                                .then(Commands.argument("player", GameProfileArgument.gameProfile())
                                        .executes(c -> cape(c, false, GameProfileArgument.getGameProfiles(c, "player"))))));
        LiteralCommandNode<CommandSourceStack> node = d.register(root);
        d.register(Commands.literal("skin").redirect(node));
    }

    // ------------------------------------------------------------------ помощники

    private static boolean op(CommandSourceStack s) {
        return s.hasPermission(2);
    }

    private static SkinStore store() {
        return ServerEvents.store();
    }

    private static List<String> visibleSkinNames(CommandSourceStack src) {
        List<String> out = new ArrayList<>();
        SkinStore st = store();
        if (st == null) return out;
        boolean admin = op(src);
        for (SkinStore.Skin k : st.list()) {
            if (admin || !k.isHd()) out.add(k.name());
        }
        return out;
    }

    private static String kind(SkinStore.Skin k) {
        return k.isHd() ? "HD" : "обычный";
    }

    private static void ok(CommandContext<CommandSourceStack> c, String msg) {
        c.getSource().sendSuccess(() -> Component.literal(msg).withStyle(ChatFormatting.GREEN), false);
    }

    private static void say(CommandContext<CommandSourceStack> c, String msg) {
        c.getSource().sendSuccess(() -> Component.literal(msg).withStyle(ChatFormatting.GRAY), false);
    }

    private static int fail(CommandContext<CommandSourceStack> c, String msg) {
        c.getSource().sendFailure(Component.literal(msg).withStyle(ChatFormatting.RED));
        return 0;
    }

    private static boolean noStore(CommandContext<CommandSourceStack> c) {
        if (store() != null) return false;
        fail(c, "Библиотека скинов недоступна (см. лог сервера).");
        return true;
    }

    // ------------------------------------------------------------------ команды

    private static int load(CommandContext<CommandSourceStack> c, String model) {
        if (noStore(c)) return 0;
        String file = StringArgumentType.getString(c, "file");
        if (file.equalsIgnoreCase("all")) {
            SkinStore.LoadAllResult r = store().loadAll(model);
            if (r.loaded().isEmpty() && r.failed().isEmpty()) return fail(c, "В папке hdskins/skins нет .png файлов.");
            ok(c, "Загружено: " + r.loaded().size() + ", с ошибками: " + r.failed().size());
            for (SkinStore.Skin k : r.loaded()) {
                say(c, "  + " + k.name() + " (" + k.size() + "x" + k.size() + ", " + kind(k) + ")");
            }
            r.failed().forEach((f, msg) -> fail(c, "  - " + f + ": " + msg));
            return r.loaded().size();
        }
        try {
            SkinStore.Skin k = store().load(file, model);
            ok(c, "Скин " + k.name() + " загружен: " + k.size() + "x" + k.size() + " (" + kind(k) + "), модель " + k.modelName() + ".");
            refreshHolders(c, k.name());
            return 1;
        } catch (SkinException e) {
            return fail(c, e.getMessage());
        }
    }

    private static int unload(CommandContext<CommandSourceStack> c) {
        if (noStore(c)) return 0;
        String name = StringArgumentType.getString(c, "skin");
        SkinStore.Skin before = store().get(name);
        try {
            int n = store().unload(name);
            ok(c, "Скин " + name.toLowerCase() + " выгружен, сброшено назначений: " + n + ".");
            if (before != null && n > 0) {
                for (ServerPlayer p : c.getSource().getServer().getPlayerList().getPlayers()) {
                    if (store().skinOf(p.getUUID()) == null) ServerEvents.broadcast(p.getUUID());
                }
            }
            return 1;
        } catch (SkinException e) {
            return fail(c, e.getMessage());
        }
    }

    private static int model(CommandContext<CommandSourceStack> c) {
        if (noStore(c)) return 0;
        try {
            SkinStore.Skin k = store().setModel(StringArgumentType.getString(c, "skin"), StringArgumentType.getString(c, "model"));
            ok(c, "Модель скина " + k.name() + ": " + k.modelName() + ".");
            refreshHolders(c, k.name());
            return 1;
        } catch (SkinException e) {
            return fail(c, e.getMessage());
        }
    }

    private static int list(CommandContext<CommandSourceStack> c) {
        if (noStore(c)) return 0;
        boolean admin = op(c.getSource());
        List<SkinStore.Skin> visible = new ArrayList<>();
        for (SkinStore.Skin k : store().list()) {
            if (admin || !k.isHd()) visible.add(k);
        }
        if (visible.isEmpty()) return fail(c, "Пока нет доступных скинов.");
        ok(c, "Доступные скины (" + visible.size() + "):");
        for (SkinStore.Skin k : visible) {
            say(c, "  " + k.name() + " - " + k.size() + "x" + k.size() + ", " + kind(k) + ", " + k.modelName());
        }
        return visible.size();
    }

    private static int apply(CommandContext<CommandSourceStack> c, Collection<GameProfile> targets) throws CommandSyntaxException {
        if (noStore(c)) return 0;
        CommandSourceStack src = c.getSource();
        String skinName = StringArgumentType.getString(c, "skin");
        SkinStore.Skin skin = store().get(skinName);
        if (skin == null) return fail(c, "Скин '" + skinName + "' не найден. Список: /hdskin list");

        boolean selfOnly;
        if (targets == null) {
            targets = List.of(src.getPlayerOrException().getGameProfile());
            selfOnly = true;
        } else {
            selfOnly = isOnlySelf(src, targets);
        }
        if (targets.isEmpty()) return fail(c, "Игрок не найден.");

        if (!selfOnly && !op(src)) return fail(c, "У вас нет прав менять скины другим игрокам.");
        if (selfOnly && skin.isHd() && !op(src)) return fail(c, "HD-скины может ставить только администратор.");

        int n = 0;
        for (GameProfile gp : targets) {
            try {
                store().assign(gp.getId(), skin.name());
            } catch (SkinException e) {
                return fail(c, e.getMessage());
            }
            ServerEvents.broadcast(gp.getId());
            n++;
            ServerPlayer online = src.getServer().getPlayerList().getPlayer(gp.getId());
            if (online != null && !(selfOnly)) {
                online.sendSystemMessage(Component.literal("Вам применён скин " + skin.name()
                        + ". Если не видите изменений - перезайдите.").withStyle(ChatFormatting.GREEN));
            }
        }
        ok(c, selfOnly ? "Скин " + skin.name() + " применён."
                : "Скин " + skin.name() + " применён игрокам: " + n + ".");
        return n;
    }


    /** /hdskin set <Ник> [игрок]: берёт скин лицензионного аккаунта с этим ником (Mojang, до 64x64). */
    private static int set(CommandContext<CommandSourceStack> c, Collection<GameProfile> targets) throws CommandSyntaxException {
        if (noStore(c)) return 0;
        CommandSourceStack src = c.getSource();
        String nick = StringArgumentType.getString(c, "nick");
        if (!SkinStore.PLAYER.matcher(nick).matches()) return fail(c, "Некорректный ник: " + nick);

        boolean selfOnly;
        if (targets == null) {
            targets = List.of(src.getPlayerOrException().getGameProfile());
            selfOnly = true;
        } else {
            selfOnly = isOnlySelf(src, targets);
        }
        if (targets.isEmpty()) return fail(c, "Игрок не найден.");
        if (!selfOnly && !op(src)) return fail(c, "У вас нет прав менять скины другим игрокам.");

        if (!op(src) && src.getEntity() instanceof ServerPlayer sp) {
            long now = System.currentTimeMillis();
            Long last = SET_COOLDOWN.get(sp.getUUID());
            if (last != null && now - last < SET_COOLDOWN_MS) {
                return fail(c, "Подождите " + ((SET_COOLDOWN_MS - (now - last)) / 1000 + 1) + " сек. перед следующим запросом.");
            }
            SET_COOLDOWN.put(sp.getUUID(), now);
        }

        say(c, "Ищу скин игрока " + nick + "...");
        MinecraftServer server = src.getServer();
        List<GameProfile> finalTargets = List.copyOf(targets);
        boolean self = selfOnly;
        CompletableFuture
                .supplyAsync(() -> {
                    try {
                        return MojangSkins.fetch(nick);
                    } catch (SkinException e) {
                        throw new CompletionException(e);
                    }
                }, FETCH_POOL)
                .whenComplete((res, err) -> server.execute(() -> finishSet(c, nick, finalTargets, self, res, err)));
        return 1;
    }

    /** Главный поток сервера: сохраняем скачанный скин и применяем. */
    private static void finishSet(CommandContext<CommandSourceStack> c, String nick, List<GameProfile> targets,
                                  boolean self, MojangSkins.Result res, Throwable err) {
        if (err != null) {
            Throwable cause = err instanceof CompletionException && err.getCause() != null ? err.getCause() : err;
            fail(c, cause instanceof SkinException ? cause.getMessage() : "Не удалось получить скин: " + cause);
            return;
        }
        SkinStore st = store();
        if (st == null) {
            fail(c, "Библиотека скинов недоступна (см. лог сервера).");
            return;
        }
        try {
            SkinStore.Skin skin = st.importBytes("mojang_" + res.realName().toLowerCase(java.util.Locale.ROOT), res.png(), res.slim());
            for (GameProfile gp : targets) {
                st.assign(gp.getId(), skin.name());
                // плащ берём, только если он есть у аккаунта; если нет - убираем прежний плащ мода
                if (res.cape() != null) {
                    try {
                        st.setCape(gp.getId(), res.cape());
                    } catch (SkinException e) {
                        st.removeCape(gp.getId());
                    }
                } else {
                    st.removeCape(gp.getId());
                }
                ServerEvents.broadcast(gp.getId());
            }
            // если этот скин уже стоял у других игроков, а файл изменился - обновим и им
            for (ServerPlayer p : c.getSource().getServer().getPlayerList().getPlayers()) {
                SkinStore.Skin cur = st.skinOf(p.getUUID());
                if (cur != null && cur.name().equals(skin.name())) ServerEvents.broadcast(p.getUUID());
            }
            String capeNote = res.cape() != null ? " Плащ тоже применён." : " Плаща у аккаунта нет - не загружен.";
            ok(c, (self ? "Скин игрока " + res.realName() + " применён (" + skin.name() + ")."
                    : "Скин игрока " + res.realName() + " применён игрокам: " + targets.size() + ".") + capeNote);
        } catch (SkinException e) {
            fail(c, e.getMessage());
        }
    }

    private static int models(CommandContext<CommandSourceStack> c) {
        if (noStore(c)) return 0;
        List<SkinStore.Model> l = store().listModels();
        if (l.isEmpty()) return fail(c, "Моделей нет. Положите файл (glb, gltf, obj, bbmodel, json) в папку hdskins/models.");
        ok(c, "3D-модели (" + l.size() + "):");
        for (SkinStore.Model m : l) {
            say(c, "  " + m.name() + " - " + m.triangles() + " треуг., поворот " + m.rot() + ", масштаб " + m.scale() + ", сдвиг " + m.yOffset());
        }
        return l.size();
    }

    private static int body(CommandContext<CommandSourceStack> c, Collection<GameProfile> targets) throws CommandSyntaxException {
        if (noStore(c)) return 0;
        CommandSourceStack src = c.getSource();
        String name = StringArgumentType.getString(c, "model");
        if (targets == null) targets = List.of(src.getPlayerOrException().getGameProfile());
        if (targets.isEmpty()) return fail(c, "Игрок не найден.");
        int n = 0;
        for (GameProfile gp : targets) {
            try {
                store().assignBody(gp.getId(), name);
            } catch (SkinException e) {
                return fail(c, e.getMessage());
            }
            ServerEvents.broadcast(gp.getId());
            n++;
        }
        ok(c, "Модель " + name.toLowerCase() + " выдана игрокам: " + n + ". Остальные увидят её, если у них стоит мод HDSkins.");
        return n;
    }

    private static int bodyOff(CommandContext<CommandSourceStack> c, Collection<GameProfile> targets) throws CommandSyntaxException {
        if (noStore(c)) return 0;
        CommandSourceStack src = c.getSource();
        if (targets == null) targets = List.of(src.getPlayerOrException().getGameProfile());
        int n = 0;
        for (GameProfile gp : targets) {
            try {
                if (store().clearBody(gp.getId())) {
                    ServerEvents.broadcast(gp.getId());
                    n++;
                }
            } catch (SkinException e) {
                return fail(c, e.getMessage());
            }
        }
        if (n == 0) return fail(c, "У игрока не было 3D-модели.");
        ok(c, "3D-модель снята у игроков: " + n + ".");
        return n;
    }

    /** /hdskin bodyfix <модель> <поворот> [масштаб] [сдвиг по высоте]: подгонка, если модель смотрит не туда или не того размера. */
    private static int bodyFix(CommandContext<CommandSourceStack> c, double scale, double y) {
        if (noStore(c)) return 0;
        String name = StringArgumentType.getString(c, "model");
        double rot = com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(c, "rot");
        FETCH_POOL.execute(() -> {
            try {
                SkinStore.Model m = store().tuneModel(name, rot, scale, y);
                c.getSource().getServer().execute(() -> {
                    ok(c, "Модель " + m.name() + ": поворот " + m.rot() + ", масштаб " + m.scale() + ", сдвиг " + m.yOffset() + ".");
                    for (ServerPlayer p : c.getSource().getServer().getPlayerList().getPlayers()) ServerEvents.broadcast(p.getUUID());
                });
            } catch (SkinException | RuntimeException e) {
                c.getSource().getServer().execute(() -> fail(c, e.getMessage()));
            }
        });
        return 1;
    }

    /** /hdskin cape on|off [игрок]: показать или скрыть плащ (любой: от Mojang или поставленный модом). */
    private static int cape(CommandContext<CommandSourceStack> c, boolean visible, Collection<GameProfile> targets) throws CommandSyntaxException {
        if (noStore(c)) return 0;
        CommandSourceStack src = c.getSource();
        boolean selfOnly;
        if (targets == null) {
            targets = List.of(src.getPlayerOrException().getGameProfile());
            selfOnly = true;
        } else {
            selfOnly = isOnlySelf(src, targets);
        }
        if (targets.isEmpty()) return fail(c, "Игрок не найден.");
        if (!selfOnly && !op(src)) return fail(c, "У вас нет прав менять плащи другим игрокам.");
        for (GameProfile gp : targets) {
            try {
                store().setCapeVisible(gp.getId(), visible);
            } catch (SkinException e) {
                return fail(c, e.getMessage());
            }
            ServerEvents.broadcast(gp.getId());
        }
        String word = visible ? "включён" : "выключен";
        ok(c, selfOnly ? "Ваш плащ " + word + "." : "Плащ " + word + " у игроков: " + targets.size() + ".");
        return targets.size();
    }

    private static boolean isOnlySelf(CommandSourceStack src, Collection<GameProfile> targets) {
        if (targets.size() != 1 || !(src.getEntity() instanceof ServerPlayer sp)) return false;
        return targets.iterator().next().getId().equals(sp.getUUID());
    }

    /** После перезагрузки файла/смены модели заново разослать скины тем, у кого он стоит. */
    private static void refreshHolders(CommandContext<CommandSourceStack> c, String skinName) {
        for (ServerPlayer p : c.getSource().getServer().getPlayerList().getPlayers()) {
            SkinStore.Skin k = store().skinOf(p.getUUID());
            if (k != null && k.name().equals(skinName)) ServerEvents.broadcast(p.getUUID());
        }
    }
}
