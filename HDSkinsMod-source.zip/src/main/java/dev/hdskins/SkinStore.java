package dev.hdskins;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.MemoryCacheImageInputStream;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Серверная библиотека скинов и назначения «игрок (UUID) -> скин». Не зависит от Minecraft.
 *
 * Папка (обычно <сервер>/hdskins/):
 *   skins/               сюда админ кладёт .png
 *   textures/<sha256>.png проверенные копии - их сервер отдаёт клиентам
 *   skins.properties     библиотека и назначения
 */
public final class SkinStore {
    /** Скин шире 64 пикселей считается HD. */
    public static final int HD_THRESHOLD = 64;
    public static final int MAX_RESOLUTION = 2048;

    /** Допустимый ник Minecraft. */
    public static final Pattern PLAYER = Pattern.compile("[A-Za-z0-9_]{1,16}");
    private static final Pattern SKIN_NAME = Pattern.compile("[a-z0-9_\\-]{1,32}");
    private static final Pattern FILE = Pattern.compile("[A-Za-z0-9_\\-.]{1,64}");

    public record Skin(String name, String hash, boolean slim, int size) {
        public boolean isHd() {
            return size > HD_THRESHOLD;
        }

        public String modelName() {
            return slim ? "slim" : "classic";
        }
    }

    public record LoadAllResult(List<Skin> loaded, Map<String, String> failed) {
    }

    /** Итог автоматической проверки папки: что новое/изменилось и что не удалось загрузить. */
    public record ScanResult(List<Skin> loaded, Map<String, String> failed, List<Model> loadedModels, List<String> removedModels) {
        public boolean modelsChanged() {
            return !loadedModels.isEmpty() || !removedModels.isEmpty();
        }
    }

    /** 3D-модель тела: file - исходный файл в папке models; rot/scale/yOffset - ручная подгонка. */
    public record Model(String name, String file, String hash, double rot, double scale, double yOffset, int triangles) {
    }

    private record Checked(byte[] png, int size) {
    }

    private final Path skinsDir;
    private final Path texturesDir;
    private final Path modelsDir;
    private final Path dataFile;
    private final Consumer<String> warn;

    private final Map<String, Skin> skins = new ConcurrentHashMap<>();
    private final Map<UUID, String> assignments = new ConcurrentHashMap<>();
    /** UUID -> sha256 плаща. Плащ есть только у тех, кому его явно поставили. */
    private final Map<String, Model> models = new ConcurrentHashMap<>();
    /** UUID -> имя модели тела */
    private final Map<UUID, String> bodies = new ConcurrentHashMap<>();
    private final Map<String, String> seenModels = new ConcurrentHashMap<>();
    private final Map<UUID, String> capes = new ConcurrentHashMap<>();
    /** игроки, у которых плащ выключен (сам плащ при этом сохраняется) */
    private final Map<UUID, Boolean> hidden = new ConcurrentHashMap<>();
    /** имя файла -> "размер:время изменения" на момент последней автозагрузки */
    private final Map<String, String> seen = new ConcurrentHashMap<>();

    public SkinStore(Path dir, Consumer<String> warn) throws IOException {
        Path base = dir.toAbsolutePath().normalize();
        this.skinsDir = base.resolve("skins");
        this.texturesDir = base.resolve("textures");
        this.modelsDir = base.resolve("models");
        this.dataFile = base.resolve("skins.properties");
        this.warn = warn;
        Files.createDirectories(skinsDir);
        Files.createDirectories(texturesDir);
        Files.createDirectories(modelsDir);
        reload();
    }

    // ------------------------------------------------------------------ чтение

    public synchronized void reload() throws IOException {
        Properties p = new Properties();
        if (Files.exists(dataFile)) {
            try (Reader r = Files.newBufferedReader(dataFile, StandardCharsets.UTF_8)) {
                p.load(r);
            }
        }
        Map<String, Skin> newSkins = new LinkedHashMap<>();
        Map<UUID, String> newAssign = new LinkedHashMap<>();
        Map<UUID, String> newCapes = new LinkedHashMap<>();
        Map<String, Model> newModels = new LinkedHashMap<>();
        Map<UUID, String> newBodies = new LinkedHashMap<>();
        Map<UUID, Boolean> newHidden = new LinkedHashMap<>();
        for (String key : p.stringPropertyNames()) {
            String v = p.getProperty(key);
            try {
                if (key.startsWith("skin.")) {
                    String name = key.substring(5);
                    String[] a = v.split("\\|");
                    if (a.length != 3 || !SKIN_NAME.matcher(name).matches() || !Util.HASH.matcher(a[0]).matches()) continue;
                    newSkins.put(name, new Skin(name, a[0], a[1].equals("slim"), Integer.parseInt(a[2])));
                } else if (key.startsWith("player.")) {
                    newAssign.put(UUID.fromString(key.substring(7)), v);
                } else if (key.startsWith("model.")) {
                    String name = key.substring(6);
                    String[] a = v.split("\\|");
                    if (a.length != 6 || !SKIN_NAME.matcher(name).matches() || !Util.HASH.matcher(a[0]).matches()) continue;
                    newModels.put(name, new Model(name, a[1], a[0], Double.parseDouble(a[2]), Double.parseDouble(a[3]),
                            Double.parseDouble(a[4]), Integer.parseInt(a[5])));
                } else if (key.startsWith("body.")) {
                    newBodies.put(UUID.fromString(key.substring(5)), v);
                } else if (key.startsWith("cape.")) {
                    if (Util.HASH.matcher(v).matches()) newCapes.put(UUID.fromString(key.substring(5)), v);
                } else if (key.startsWith("hidden.")) {
                    newHidden.put(UUID.fromString(key.substring(7)), Boolean.TRUE);
                }
            } catch (IllegalArgumentException ignored) {
                // битая строка (NumberFormatException и неверный UUID - подклассы) - пропускаем
            }
        }
        newSkins.values().removeIf(s -> {
            boolean missing = !Files.isRegularFile(texturesDir.resolve(s.hash() + ".png"));
            if (missing) warn.accept("HDSkins: текстура скина '" + s.name() + "' не найдена, скин удалён из библиотеки.");
            return missing;
        });
        newAssign.values().removeIf(n -> !newSkins.containsKey(n));
        newModels.values().removeIf(m -> !Files.isRegularFile(texturesDir.resolve(m.hash() + ".hdm")));
        newBodies.values().removeIf(n -> !newModels.containsKey(n));
        models.clear();
        models.putAll(newModels);
        bodies.clear();
        bodies.putAll(newBodies);
        newCapes.values().removeIf(h -> !Files.isRegularFile(texturesDir.resolve(h + ".png")));
        capes.clear();
        capes.putAll(newCapes);
        hidden.clear();
        hidden.putAll(newHidden);
        skins.clear();
        skins.putAll(newSkins);
        assignments.clear();
        assignments.putAll(newAssign);
    }

    public Skin get(String name) {
        return name == null ? null : skins.get(name.toLowerCase(Locale.ROOT));
    }

    public List<Skin> list() {
        List<Skin> l = new ArrayList<>(skins.values());
        l.sort(Comparator.comparing(Skin::name));
        return l;
    }

    /** Имена .png в папке skins. */
    public List<String> listFiles() {
        try (Stream<Path> st = Files.list(skinsDir)) {
            return st.filter(Files::isRegularFile)
                    .map(f -> f.getFileName().toString())
                    .filter(n -> n.toLowerCase(Locale.ROOT).endsWith(".png"))
                    .sorted()
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    // ------------------------------------------------------------------ загрузка

    /**
     * Загружает skins/<файл>.png в библиотеку. Имя скина = имя файла без .png в нижнем регистре.
     *
     * @param modelArg slim / classic; null - оставить прежнюю модель, а для нового скина: slim, если имя
     *                 заканчивается на _slim или -slim, иначе classic
     */
    public Skin load(String fileArg, String modelArg) throws SkinException {
        Path file = resolveSkinFile(fileArg);
        String name = nameOf(file.getFileName().toString());
        if (!SKIN_NAME.matcher(name).matches()) {
            throw new SkinException("Имя файла даёт недопустимое имя скина (латиница, цифры, _ -; до 32 символов).");
        }
        Boolean explicit = modelArg == null ? null : parseModel(modelArg);
        byte[] data;
        try {
            long size = Files.size(file);
            if (size > ChunkAssembler.MAX_BYTES) {
                throw new SkinException("Файл слишком большой: " + size / 1024 + " КБ (максимум " + ChunkAssembler.MAX_BYTES / 1024 + " КБ).");
            }
            data = Files.readAllBytes(file);
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
        boolean slim;
        if (explicit != null) {
            slim = explicit;
        } else {
            Skin old = skins.get(name);
            slim = old != null ? old.slim() : (name.endsWith("_slim") || name.endsWith("-slim"));
        }
        return register(name, data, slim);
    }

    /** Добавляет скин из байтов PNG (например, скачанный по нику), без файла в папке skins. */
    public Skin importBytes(String name, byte[] data, boolean slim) throws SkinException {
        if (!SKIN_NAME.matcher(name).matches()) throw new SkinException("Недопустимое имя скина.");
        if (data.length > ChunkAssembler.MAX_BYTES) throw new SkinException("Файл слишком большой.");
        return register(name, data, slim);
    }

    private Skin register(String name, byte[] raw, boolean slim) throws SkinException {
        Checked c = check(raw);
        String hash = Util.sha256(c.png());
        try {
            Path tex = texturesDir.resolve(hash + ".png");
            if (!Files.exists(tex)) Files.write(tex, c.png());
            Skin skin = new Skin(name, hash, slim, c.size());
            synchronized (this) {
                Skin old = skins.put(name, skin);
                save();
                if (old != null && !old.hash().equals(hash)) cleanupTexture(old.hash());
            }
            return skin;
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
    }

    private static String nameOf(String fileName) {
        return nameOf(fileName, 4);
    }

    private static String nameOf(String fileName, int extLength) {
        return fileName.substring(0, fileName.length() - extLength).toLowerCase(Locale.ROOT);
    }

    /**
     * Автозагрузка: находит в skins/ новые и изменённые .png и загружает их. Файлы, изменённые менее 2 секунд
     * назад (ещё копируются), пропускаются до следующей проверки. Удалённые файлы скины из библиотеки не убирают.
     */
    public ScanResult autoScan() {
        List<Skin> ok = new ArrayList<>();
        Map<String, String> bad = new LinkedHashMap<>();
        List<String> files = listFiles();
        seen.keySet().retainAll(files);
        long now = System.currentTimeMillis();
        for (String f : files) {
            String sig;
            long mtime;
            try {
                Path p = skinsDir.resolve(f);
                mtime = Files.getLastModifiedTime(p).toMillis();
                sig = Files.size(p) + ":" + mtime;
            } catch (IOException e) {
                continue;
            }
            if (sig.equals(seen.get(f))) continue;
            if (now - mtime < 2000) continue;
            seen.put(f, sig);
            Skin old = get(nameOf(f));
            try {
                Skin k = load(f, null);
                if (old == null || !old.hash().equals(k.hash())) ok.add(k);
            } catch (SkinException e) {
                bad.put(f, e.getMessage());
            }
        }
        List<Model> okModels = new ArrayList<>();
        List<String> removed = new ArrayList<>();
        scanModels(okModels, removed, bad);
        return new ScanResult(ok, bad, okModels, removed);
    }

    public LoadAllResult loadAll(String modelArg) {
        List<Skin> ok = new ArrayList<>();
        Map<String, String> bad = new LinkedHashMap<>();
        for (String f : listFiles()) {
            try {
                ok.add(load(f, modelArg));
            } catch (SkinException e) {
                bad.put(f, e.getMessage());
            }
        }
        return new LoadAllResult(ok, bad);
    }

    /** @return сколько назначений сброшено */
    public int unload(String name) throws SkinException {
        Skin s = get(name);
        if (s == null) throw new SkinException("Скин '" + name + "' не найден.");
        try {
            synchronized (this) {
                skins.remove(s.name());
                int[] cleared = {0};
                assignments.values().removeIf(n -> {
                    boolean hit = n.equals(s.name());
                    if (hit) cleared[0]++;
                    return hit;
                });
                save();
                cleanupTexture(s.hash());
                return cleared[0];
            }
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
    }

    public Skin setModel(String name, String modelArg) throws SkinException {
        Skin s = get(name);
        if (s == null) throw new SkinException("Скин '" + name + "' не найден.");
        Skin n = new Skin(s.name(), s.hash(), parseModel(modelArg), s.size());
        try {
            synchronized (this) {
                skins.put(n.name(), n);
                save();
            }
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
        return n;
    }

    // ------------------------------------------------------------------ назначения

    public Skin assign(UUID player, String skinName) throws SkinException {
        Skin s = get(skinName);
        if (s == null) throw new SkinException("Скин '" + skinName + "' не найден.");
        try {
            synchronized (this) {
                assignments.put(player, s.name());
                save();
            }
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
        return s;
    }

    public Skin skinOf(UUID player) {
        String n = assignments.get(player);
        return n == null ? null : skins.get(n);
    }

    // ------------------------------------------------------------------ 3D-модели тела

    public Model getModel(String name) {
        return name == null ? null : models.get(name.toLowerCase(Locale.ROOT));
    }

    public List<Model> listModels() {
        List<Model> l = new ArrayList<>(models.values());
        l.sort(Comparator.comparing(Model::name));
        return l;
    }

    /** Имена файлов моделей в папке models. */
    public List<String> listModelFiles() {
        try (Stream<Path> st = Files.list(modelsDir)) {
            return st.filter(Files::isRegularFile)
                    .map(f -> f.getFileName().toString())
                    .filter(n -> ModelCodec.EXTENSIONS.contains(ModelCodec.extension(n)))
                    .sorted()
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    public Model bodyOf(UUID player) {
        String n = bodies.get(player);
        return n == null ? null : models.get(n);
    }

    public Model assignBody(UUID player, String modelName) throws SkinException {
        Model m = getModel(modelName);
        if (m == null) throw new SkinException("Модель '" + modelName + "' не найдена. Список: /hdskin models");
        try {
            synchronized (this) {
                bodies.put(player, m.name());
                save();
            }
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
        return m;
    }

    /** @return true, если у игрока была модель тела */
    public boolean clearBody(UUID player) throws SkinException {
        try {
            synchronized (this) {
                boolean had = bodies.remove(player) != null;
                if (had) save();
                return had;
            }
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
    }

    /** Подгонка модели: поворот (градусы), масштаб (1 = рост игрока 1.8) и сдвиг по высоте. Модель пересобирается из файла. */
    public Model tuneModel(String name, double rot, double scale, double yOffset) throws SkinException {
        Model m = getModel(name);
        if (m == null) throw new SkinException("Модель '" + name + "' не найдена.");
        if (!(scale >= 0.05 && scale <= 20) || Math.abs(yOffset) > 20) {
            throw new SkinException("Масштаб должен быть от 0.05 до 20, сдвиг - не больше 20 блоков.");
        }
        return buildModel(m.file(), rot, scale, yOffset);
    }

    /** Загружает файл из папки models (формат по расширению), сохраняя прежнюю подгонку, если она была. */
    public Model loadModel(String fileName) throws SkinException {
        Path file = resolveModelFile(fileName);
        String name = nameOf(file.getFileName().toString(), ModelCodec.extension(fileName).length() + 1);
        Model old = models.get(name);
        return buildModel(file.getFileName().toString(), old == null ? 0 : old.rot(), old == null ? 1 : old.scale(),
                old == null ? 0 : old.yOffset());
    }

    private Model buildModel(String fileName, double rot, double scale, double yOffset) throws SkinException {
        Path file = resolveModelFile(fileName);
        String name = nameOf(fileName, ModelCodec.extension(fileName).length() + 1);
        if (!SKIN_NAME.matcher(name).matches()) {
            throw new SkinException("Имя файла даёт недопустимое имя модели (латиница, цифры, _ -; до 32 символов).");
        }
        Mesh mesh = ModelCodec.load(file);
        ModelCodec.normalize(mesh, rot, scale, yOffset);
        byte[] blob = ModelCodec.encode(mesh);
        String hash = Util.sha256(blob);
        try {
            Path tex = texturesDir.resolve(hash + ".hdm");
            if (!Files.exists(tex)) Files.write(tex, blob);
            Model m = new Model(name, file.getFileName().toString(), hash, rot, scale, yOffset, mesh.triangles());
            synchronized (this) {
                Model prev = models.put(name, m);
                save();
                if (prev != null && !prev.hash().equals(hash)) cleanupTexture(prev.hash());
            }
            return m;
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
    }

    private Path resolveModelFile(String arg) throws SkinException {
        if (arg == null || !FILE.matcher(arg).matches() || arg.startsWith(".")
                || !ModelCodec.EXTENSIONS.contains(ModelCodec.extension(arg))) {
            throw new SkinException("Недопустимое имя файла модели (форматы: glb, gltf, obj, bbmodel, json).");
        }
        Path p = modelsDir.resolve(arg).normalize();
        if (!p.startsWith(modelsDir) || !Files.isRegularFile(p)) throw new SkinException("Файл " + arg + " не найден в папке hdskins/models.");
        try {
            if (!p.toRealPath().startsWith(modelsDir.toRealPath())) throw new SkinException("Недопустимое имя файла.");
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
        return p;
    }

    /**
     * Автозагрузка моделей: новые/изменённые файлы (и изменения вспомогательных файлов рядом: текстуры, .mtl, .bin)
     * пересобираются, пропавшие файлы убирают модель вместе с назначениями.
     */
    private void scanModels(List<Model> ok, List<String> removed, Map<String, String> bad) {
        List<String> files = listModelFiles();
        seenModels.keySet().retainAll(files);
        long now = System.currentTimeMillis();
        StringBuilder side = new StringBuilder();
        long newest = 0;
        try (Stream<Path> st = Files.list(modelsDir)) {
            for (Path f : st.filter(Files::isRegularFile).sorted().toList()) {
                String fn = f.getFileName().toString();
                if (ModelCodec.EXTENSIONS.contains(ModelCodec.extension(fn))) {
                    newest = Math.max(newest, Files.getLastModifiedTime(f).toMillis());
                    continue;
                }
                long mt = Files.getLastModifiedTime(f).toMillis();
                newest = Math.max(newest, mt);
                side.append(fn).append(':').append(Files.size(f)).append(':').append(mt).append(';');
            }
        } catch (IOException e) {
            return;
        }
        for (String f : files) {
            String sig;
            try {
                Path p = modelsDir.resolve(f);
                sig = Files.size(p) + ":" + Files.getLastModifiedTime(p).toMillis() + ":" + side;
            } catch (IOException e) {
                continue;
            }
            if (sig.equals(seenModels.get(f))) continue;
            if (now - newest < 2000) continue; // что-то ещё копируется
            seenModels.put(f, sig);
            Model old = models.get(nameOf(f, ModelCodec.extension(f).length() + 1));
            try {
                Model m = loadModel(f);
                if (old == null || !old.hash().equals(m.hash())) ok.add(m);
            } catch (SkinException e) {
                bad.put("models/" + f, e.getMessage());
            }
        }
        for (Model m : new ArrayList<>(models.values())) {
            if (files.contains(m.file())) continue;
            try {
                synchronized (this) {
                    models.remove(m.name());
                    bodies.values().removeIf(n -> n.equals(m.name()));
                    save();
                    cleanupTexture(m.hash());
                }
                removed.add(m.name());
            } catch (IOException e) {
                bad.put("models/" + m.file(), "Ошибка ввода-вывода: " + e.getMessage());
            }
        }
    }

    // ------------------------------------------------------------------ плащи

    /** Ставит игроку плащ из PNG (64x32, 128x64 ... до 2048 в ширину). Плащ при этом включается. */
    public String setCape(UUID player, byte[] raw) throws SkinException {
        if (raw.length > ChunkAssembler.MAX_BYTES) throw new SkinException("Файл слишком большой.");
        byte[] png = checkCape(raw);
        String hash = Util.sha256(png);
        try {
            Path tex = texturesDir.resolve(hash + ".png");
            if (!Files.exists(tex)) Files.write(tex, png);
            synchronized (this) {
                String old = capes.put(player, hash);
                hidden.remove(player);
                save();
                if (old != null && !old.equals(hash)) cleanupTexture(old);
            }
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
        return hash;
    }

    /** Убирает плащ игрока совсем (нужно, когда по нику скин ставится, а плаща у аккаунта нет). */
    public void removeCape(UUID player) throws SkinException {
        try {
            synchronized (this) {
                String old = capes.remove(player);
                boolean h = hidden.remove(player) != null;
                if (old != null || h) save();
                if (old != null) cleanupTexture(old);
            }
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
    }

    /** Включает/выключает показ плаща игрока (и поставленного модом, и обычного от Mojang). */
    public void setCapeVisible(UUID player, boolean visible) throws SkinException {
        try {
            synchronized (this) {
                if (visible) hidden.remove(player);
                else hidden.put(player, Boolean.TRUE);
                save();
            }
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
    }

    /** sha256 плаща или null, если плаща нет. */
    public String capeOf(UUID player) {
        return capes.get(player);
    }

    public boolean capeHidden(UUID player) {
        return hidden.containsKey(player);
    }

    /** Размеры плаща: w = 2h, w кратно 64 (64x32 - стандарт Mojang). */
    private static byte[] checkCape(byte[] d) throws SkinException {
        if (d.length < 8 || d[0] != (byte) 0x89 || d[1] != 'P' || d[2] != 'N' || d[3] != 'G') {
            throw new SkinException("Плащ не является PNG.");
        }
        ImageReader reader = null;
        try (ImageInputStream in = new MemoryCacheImageInputStream(new ByteArrayInputStream(d))) {
            Iterator<ImageReader> it = ImageIO.getImageReaders(in);
            if (!it.hasNext()) throw new SkinException("Плащ не является PNG.");
            reader = it.next();
            reader.setInput(in, true, true);
            int w = reader.getWidth(0);
            int h = reader.getHeight(0);
            if (w != h * 2 || w < 64 || w % 64 != 0 || w > MAX_RESOLUTION) {
                throw new SkinException("Недопустимый размер плаща " + w + "x" + h + ": нужно 64x32, 128x64 и т.д.");
            }
            if (reader.read(0) == null) throw new SkinException("PNG плаща повреждён.");
            return d;
        } catch (IOException | RuntimeException e) {
            throw new SkinException("PNG плаща повреждён или не читается.");
        } finally {
            if (reader != null) reader.dispose();
        }
    }

    // ------------------------------------------------------------------ для передачи клиентам

    /** Байты PNG по хэшу, только если хэш принадлежит загруженному скину; иначе null. */
    public byte[] readTexture(String hash) {
        if (hash == null || !Util.HASH.matcher(hash).matches()) return null;
        boolean known = capes.containsValue(hash);
        boolean isModel = false;
        for (Model m : models.values()) {
            if (m.hash().equals(hash)) {
                known = true;
                isModel = true;
                break;
            }
        }
        for (Skin s : skins.values()) {
            if (s.hash().equals(hash)) {
                known = true;
                break;
            }
        }
        if (!known) return null;
        try {
            return Files.readAllBytes(texturesDir.resolve(hash + (isModel ? ".hdm" : ".png")));
        } catch (IOException e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ внутреннее

    private Path resolveSkinFile(String arg) throws SkinException {
        if (arg == null || !FILE.matcher(arg).matches() || arg.startsWith(".")) {
            throw new SkinException("Недопустимое имя файла (латиница, цифры, _ - .).");
        }
        String fn = arg.toLowerCase(Locale.ROOT).endsWith(".png") ? arg : arg + ".png";
        Path p = skinsDir.resolve(fn).normalize();
        if (!p.startsWith(skinsDir)) throw new SkinException("Недопустимое имя файла.");
        if (!Files.isRegularFile(p)) throw new SkinException("Файл " + fn + " не найден в папке hdskins/skins.");
        try {
            if (!p.toRealPath().startsWith(skinsDir.toRealPath())) throw new SkinException("Недопустимое имя файла.");
        } catch (IOException e) {
            throw new SkinException("Ошибка ввода-вывода: " + e.getMessage());
        }
        return p;
    }

    static boolean parseModel(String m) throws SkinException {
        String s = m == null ? "" : m.toLowerCase(Locale.ROOT);
        return switch (s) {
            case "slim", "alex" -> true;
            case "classic", "default", "steve", "wide" -> false;
            default -> throw new SkinException("Модель должна быть slim или classic.");
        };
    }

    /**
     * Проверяет PNG и размеры ДО полной декодировки. Принимаются квадраты 64, 128 ... 2048 и старый формат
     * "ширина x ширина/2" (он переводится в квадрат).
     */
    private static Checked check(byte[] d) throws SkinException {
        if (d.length < 8 || d[0] != (byte) 0x89 || d[1] != 'P' || d[2] != 'N' || d[3] != 'G'
                || d[4] != 0x0D || d[5] != 0x0A || d[6] != 0x1A || d[7] != 0x0A) {
            throw new SkinException("Файл не является PNG.");
        }
        ImageReader reader = null;
        try (ImageInputStream in = new MemoryCacheImageInputStream(new ByteArrayInputStream(d))) {
            Iterator<ImageReader> it = ImageIO.getImageReaders(in);
            if (!it.hasNext()) throw new SkinException("Файл не является PNG.");
            reader = it.next();
            reader.setInput(in, true, true);
            int w = reader.getWidth(0);
            int h = reader.getHeight(0);
            boolean legacy = h * 2 == w;
            if (!(w == h || legacy) || w < 64 || w % 64 != 0) {
                throw new SkinException("Недопустимый размер " + w + "x" + h
                        + ": нужен квадрат со стороной, кратной 64 (64x64, 128x128, 256x256...), либо 64x32.");
            }
            if (w > MAX_RESOLUTION) throw new SkinException("Разрешение " + w + "x" + h + " больше лимита " + MAX_RESOLUTION + ".");
            BufferedImage img = reader.read(0); // убеждаемся, что файл целиком декодируется
            if (img == null) throw new SkinException("PNG повреждён или не читается.");
            if (!legacy) return new Checked(d, w);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            ImageIO.write(LegacySkin.convert(img), "png", bo);
            return new Checked(bo.toByteArray(), w);
        } catch (IOException | RuntimeException e) {
            throw new SkinException("PNG повреждён или не читается.");
        } finally {
            if (reader != null) reader.dispose();
        }
    }

    private void cleanupTexture(String hash) {
        if (capes.containsValue(hash)) return;
        for (Skin s : skins.values()) {
            if (s.hash().equals(hash)) return;
        }
        for (Model m : models.values()) {
            if (m.hash().equals(hash)) return;
        }
        try {
            Files.deleteIfExists(texturesDir.resolve(hash + ".png"));
            Files.deleteIfExists(texturesDir.resolve(hash + ".hdm"));
        } catch (IOException ignored) {
            // не критично
        }
    }

    private void save() throws IOException {
        Properties p = new Properties();
        for (Skin s : skins.values()) {
            p.setProperty("skin." + s.name(), s.hash() + "|" + (s.slim() ? "slim" : "classic") + "|" + s.size());
        }
        for (Map.Entry<UUID, String> e : assignments.entrySet()) {
            p.setProperty("player." + e.getKey(), e.getValue());
        }
        for (Model m : models.values()) {
            p.setProperty("model." + m.name(), m.hash() + "|" + m.file() + "|" + m.rot() + "|" + m.scale() + "|"
                    + m.yOffset() + "|" + m.triangles());
        }
        for (Map.Entry<UUID, String> e : bodies.entrySet()) {
            p.setProperty("body." + e.getKey(), e.getValue());
        }
        for (Map.Entry<UUID, String> e : capes.entrySet()) {
            p.setProperty("cape." + e.getKey(), e.getValue());
        }
        for (UUID u : hidden.keySet()) {
            p.setProperty("hidden." + u, "1");
        }
        Path tmp = dataFile.resolveSibling("skins.properties.tmp");
        try (Writer w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
            p.store(w, "HDSkins data");
        }
        try {
            Files.move(tmp, dataFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, dataFile, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
