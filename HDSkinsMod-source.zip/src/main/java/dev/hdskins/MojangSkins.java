package dev.hdskins;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Получение скина лицензионного аккаунта по нику (серверы Mojang). Скин там не больше 64x64.
 * Блокирующий вызов: запускать не в главном потоке сервера.
 */
public final class MojangSkins {
    /** cape - PNG плаща или null, если у аккаунта плаща нет */
    public record Result(byte[] png, boolean slim, String realName, byte[] cape) {
    }

    private static final Pattern PROFILE_ID = Pattern.compile("\"id\"\\s*:\\s*\"([0-9a-fA-F]{32})\"");
    private static final Pattern PROFILE_NAME = Pattern.compile("\"name\"\\s*:\\s*\"([A-Za-z0-9_]{1,16})\"");
    private static final Pattern TEXTURES_VALUE = Pattern.compile("\"value\"\\s*:\\s*\"([A-Za-z0-9+/=]+)\"");
    private static final Pattern SKIN_URL = Pattern.compile(
            "\"SKIN\"\\s*:\\s*\\{[^}]*?\"url\"\\s*:\\s*\"https?://textures\\.minecraft\\.net/texture/([0-9a-f]{1,128})\"");
    private static final Pattern CAPE_URL = Pattern.compile(
            "\"CAPE\"\\s*:\\s*\\{[^}]*?\"url\"\\s*:\\s*\"https?://textures\\.minecraft\\.net/texture/([0-9a-f]{1,128})\"");
    private static final Pattern SLIM = Pattern.compile("\"model\"\\s*:\\s*\"slim\"");

    private static final int MAX_JSON = 256 * 1024;
    private static final int MAX_PNG = 1024 * 1024;

    private MojangSkins() {
    }

    public static Result fetch(String nick) throws SkinException {
        if (!SkinStore.PLAYER.matcher(nick).matches()) throw new SkinException("Некорректный ник: " + nick);
        HttpClient http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5))
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();

        byte[] lookup = get(http, "https://api.mojang.com/users/profiles/minecraft/" + nick, MAX_JSON);
        if (lookup == null) throw new SkinException("Игрок с ником " + nick + " не найден (скины есть только у лицензионных аккаунтов).");
        String lookupJson = new String(lookup, StandardCharsets.UTF_8);
        String id = first(PROFILE_ID, lookupJson);
        if (id == null) throw new SkinException("Mojang вернул неожиданный ответ для ника " + nick + ".");
        String realName = first(PROFILE_NAME, lookupJson);

        byte[] profile = get(http, "https://sessionserver.mojang.com/session/minecraft/profile/" + id, MAX_JSON);
        if (profile == null) throw new SkinException("У игрока " + nick + " нет профиля скина.");
        String value = first(TEXTURES_VALUE, new String(profile, StandardCharsets.UTF_8));
        if (value == null) throw new SkinException("У игрока " + nick + " нет скина.");

        String textures;
        try {
            textures = new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            throw new SkinException("Mojang вернул неожиданный ответ для ника " + nick + ".");
        }
        String hash = parseSkinHash(textures);
        if (hash == null) throw new SkinException("У игрока " + nick + " нет собственного скина (используется стандартный).");

        byte[] png = get(http, "https://textures.minecraft.net/texture/" + hash, MAX_PNG);
        if (png == null) throw new SkinException("Не удалось скачать скин игрока " + nick + ".");
        byte[] cape = null;
        String capeHash = parseCapeHash(textures);
        if (capeHash != null) {
            try {
                cape = get(http, "https://textures.minecraft.net/texture/" + capeHash, MAX_PNG);
            } catch (SkinException e) {
                cape = null; // плащ не скачался - просто остаёмся без плаща
            }
        }
        return new Result(png, parseSlim(textures), realName == null ? nick : realName, cape);
    }

    /** Хэш текстуры SKIN из расшифрованного JSON свойства textures (только textures.minecraft.net) или null. */
    static String parseSkinHash(String texturesJson) {
        return first(SKIN_URL, texturesJson);
    }

    /** Хэш текстуры CAPE или null, если у аккаунта плаща нет. */
    static String parseCapeHash(String texturesJson) {
        return first(CAPE_URL, texturesJson);
    }

    /** true, если у SKIN указана модель slim. */
    static boolean parseSlim(String texturesJson) {
        int skin = texturesJson.indexOf("\"SKIN\"");
        if (skin < 0) return false;
        int cape = texturesJson.indexOf("\"CAPE\"", skin);
        String part = cape > skin ? texturesJson.substring(skin, cape) : texturesJson.substring(skin);
        return SLIM.matcher(part).find();
    }

    private static String first(Pattern p, String s) {
        Matcher m = p.matcher(s);
        return m.find() ? m.group(1) : null;
    }

    /** @return тело ответа; null, если 404/204 (нет такого) */
    private static byte[] get(HttpClient http, String url, int limit) throws SkinException {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(10))
                    .header("User-Agent", "HDSkins")
                    .GET().build();
            HttpResponse<byte[]> resp = http.send(req, HttpResponse.BodyHandlers.ofByteArray());
            int code = resp.statusCode();
            if (code == 404 || code == 204) return null;
            if (code == 429) throw new SkinException("Mojang временно ограничил запросы, попробуйте через минуту.");
            if (code != 200) throw new SkinException("Mojang ответил кодом " + code + ".");
            if (resp.body().length > limit) throw new SkinException("Ответ Mojang слишком большой.");
            return resp.body();
        } catch (IOException e) {
            throw new SkinException("Не удалось связаться с серверами Mojang (" + e.getClass().getSimpleName() + ").");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SkinException("Запрос прерван.");
        }
    }
}
