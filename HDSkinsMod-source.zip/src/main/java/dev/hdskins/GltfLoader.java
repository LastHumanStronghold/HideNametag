package dev.hdskins;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** glTF 2.0 (.gltf с внешними файлами или встроенными данными, и .glb). Статичная поза, без анимаций. */
final class GltfLoader {
    private final Path dir;
    private final Map<String, Object> root;
    private final List<byte[]> buffers = new ArrayList<>();
    private final Mesh mesh = new Mesh();
    private final Map<String, Integer> texSlots = new HashMap<>();
    private byte[] glbBin;

    private GltfLoader(Path dir, Map<String, Object> root, byte[] glbBin) {
        this.dir = dir;
        this.root = root;
        this.glbBin = glbBin;
    }

    static Mesh load(Path file) throws SkinException {
        Path dir = file.toAbsolutePath().getParent();
        byte[] data = Imgs.readLimited(file);
        String json;
        byte[] bin = null;
        if (data.length >= 12 && data[0] == 'g' && data[1] == 'l' && data[2] == 'T' && data[3] == 'F') {
            ByteBuffer b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
            int pos = 12;
            String j = null;
            while (pos + 8 <= data.length) {
                int len = b.getInt(pos);
                int type = b.getInt(pos + 4);
                pos += 8;
                if (len < 0 || pos + len > data.length) throw new SkinException("Файл GLB повреждён.");
                if (type == 0x4E4F534A && j == null) j = new String(data, pos, len, StandardCharsets.UTF_8);
                else if (type == 0x004E4942 && bin == null) bin = java.util.Arrays.copyOfRange(data, pos, pos + len);
                pos += (len + 3) & ~3;
            }
            if (j == null) throw new SkinException("В GLB нет данных JSON.");
            json = j;
        } else {
            json = new String(data, StandardCharsets.UTF_8);
        }
        Map<String, Object> root = Json.obj(Json.parse(json));
        if (root == null) throw new SkinException("Файл не похож на glTF.");
        return new GltfLoader(dir, root, bin).run();
    }

    private Mesh run() throws SkinException {
        List<Object> req = Json.arr(root.get("extensionsRequired"));
        if (req != null) {
            for (Object o : req) {
                String e = Json.str(o);
                if ("KHR_draco_mesh_compression".equals(e) || "EXT_meshopt_compression".equals(e)) {
                    throw new SkinException("Сжатые модели (" + e + ") не поддерживаются: экспортируйте без Draco/meshopt.");
                }
            }
        }
        List<Object> bufs = Json.arr(root.get("buffers"));
        if (bufs != null) {
            for (int k = 0; k < bufs.size(); k++) buffers.add(readBuffer(Json.obj(bufs.get(k)), k));
        }
        List<Object> scenes = Json.arr(root.get("scenes"));
        List<Object> nodes = Json.arr(root.get("nodes"));
        List<Integer> roots = new ArrayList<>();
        if (scenes != null && !scenes.isEmpty()) {
            int si = (int) Json.num(root.get("scene"), 0);
            Map<String, Object> sc = Json.obj(scenes.get(Math.max(0, Math.min(si, scenes.size() - 1))));
            List<Object> rn = sc == null ? null : Json.arr(sc.get("nodes"));
            if (rn != null) for (Object o : rn) roots.add((int) Json.num(o, -1));
        } else if (nodes != null) {
            for (int k = 0; k < nodes.size(); k++) roots.add(k);
        }
        for (int r : roots) visit(r, Xf.identity(), 0);
        mesh.frontRotation = 0; // glTF: перед модели смотрит в +Z, как в Minecraft
        return mesh.finish();
    }

    private byte[] readBuffer(Map<String, Object> b, int index) throws SkinException {
        if (b == null) throw new SkinException("Повреждён список buffers.");
        String uri = Json.str(b.get("uri"));
        if (uri == null) {
            if (glbBin == null || index != 0) throw new SkinException("В glTF не найден двоичный буфер.");
            return glbBin;
        }
        return readUri(uri);
    }

    private byte[] readUri(String uri) throws SkinException {
        if (uri.startsWith("data:")) {
            int c = uri.indexOf(',');
            if (c < 0) throw new SkinException("Некорректный data-URI.");
            try {
                return Base64.getDecoder().decode(uri.substring(c + 1).trim());
            } catch (IllegalArgumentException e) {
                throw new SkinException("Некорректные данные base64 в glTF.");
            }
        }
        String dec;
        try {
            dec = java.net.URLDecoder.decode(uri.replace("+", "%2B"), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            dec = uri;
        }
        Path p = Imgs.findNear(dir, dec);
        if (p == null) throw new SkinException("Не найден файл, на который ссылается модель: " + uri);
        return Imgs.readLimited(p);
    }

    private void visit(int idx, Xf parent, int depth) throws SkinException {
        List<Object> nodes = Json.arr(root.get("nodes"));
        if (nodes == null || idx < 0 || idx >= nodes.size() || depth > 64) return;
        Map<String, Object> n = Json.obj(nodes.get(idx));
        if (n == null) return;
        Xf local;
        double[] mat = Json.nums(n.get("matrix"), 16);
        if (mat != null) {
            local = Xf.fromColumnMajor(mat);
        } else {
            double[] t = Json.nums(n.get("translation"), 3);
            double[] r = Json.nums(n.get("rotation"), 4);
            double[] s = Json.nums(n.get("scale"), 3);
            local = Xf.identity();
            if (t != null) local = local.mul(Xf.translate(t[0], t[1], t[2]));
            if (r != null) local = local.mul(Xf.quat(r[0], r[1], r[2], r[3]));
            if (s != null) local = local.mul(Xf.scale(s[0], s[1], s[2]));
        }
        Xf world = parent.mul(local);
        int mi = (int) Json.num(n.get("mesh"), -1);
        List<Object> meshes = Json.arr(root.get("meshes"));
        if (mi >= 0 && meshes != null && mi < meshes.size()) {
            Map<String, Object> m = Json.obj(meshes.get(mi));
            List<Object> prims = m == null ? null : Json.arr(m.get("primitives"));
            if (prims != null) for (Object p : prims) primitive(Json.obj(p), world);
        }
        List<Object> ch = Json.arr(n.get("children"));
        if (ch != null) for (Object c : ch) visit((int) Json.num(c, -1), world, depth + 1);
    }

    private void primitive(Map<String, Object> p, Xf xf) throws SkinException {
        if (p == null) return;
        int mode = (int) Json.num(p.get("mode"), 4);
        if (mode < 4 || mode > 6) return; // точки и линии не рисуем
        Map<String, Object> attr = Json.obj(p.get("attributes"));
        if (attr == null || !attr.containsKey("POSITION")) return;
        float[] pos = readFloats((int) Json.num(attr.get("POSITION"), -1), 3);
        float[] nrm = attr.containsKey("NORMAL") ? readFloats((int) Json.num(attr.get("NORMAL"), -1), 3) : null;
        float[] uv = attr.containsKey("TEXCOORD_0") ? readFloats((int) Json.num(attr.get("TEXCOORD_0"), -1), 2) : null;
        int vc = pos.length / 3;
        if (nrm != null && nrm.length / 3 != vc) nrm = null;
        if (uv != null && uv.length / 2 != vc) uv = null;

        int[] idx;
        if (p.containsKey("indices")) {
            idx = readIndices((int) Json.num(p.get("indices"), -1));
        } else {
            idx = new int[vc];
            for (int k = 0; k < vc; k++) idx[k] = k;
        }
        int tex = textureFor((int) Json.num(p.get("material"), -1));

        List<int[]> tris = new ArrayList<>();
        if (mode == 4) {
            for (int k = 0; k + 2 < idx.length; k += 3) tris.add(new int[]{idx[k], idx[k + 1], idx[k + 2]});
        } else if (mode == 5) {
            for (int k = 0; k + 2 < idx.length; k++) {
                tris.add(k % 2 == 0 ? new int[]{idx[k], idx[k + 1], idx[k + 2]} : new int[]{idx[k + 1], idx[k], idx[k + 2]});
            }
        } else {
            for (int k = 1; k + 1 < idx.length; k++) tris.add(new int[]{idx[0], idx[k], idx[k + 1]});
        }
        for (int[] t : tris) {
            double[][] ps = new double[3][];
            double[][] ns = nrm == null ? null : new double[3][];
            float[] tuv = new float[6];
            for (int k = 0; k < 3; k++) {
                int v = t[k];
                if (v < 0 || v >= vc) throw new SkinException("В glTF индекс вершины вне диапазона.");
                ps[k] = xf.pt(pos[v * 3], pos[v * 3 + 1], pos[v * 3 + 2]);
                if (ns != null) ns[k] = xf.dir(nrm[v * 3], nrm[v * 3 + 1], nrm[v * 3 + 2]);
                if (uv != null) {
                    tuv[k * 2] = uv[v * 2];
                    tuv[k * 2 + 1] = uv[v * 2 + 1];
                }
            }
            mesh.add(tex, ps[0], ps[1], ps[2], tuv, ns);
        }
    }

    private int textureFor(int matIndex) throws SkinException {
        int argb = 0xFFCCCCCC;
        int imageIndex = -1;
        List<Object> mats = Json.arr(root.get("materials"));
        if (mats != null && matIndex >= 0 && matIndex < mats.size()) {
            Map<String, Object> m = Json.obj(mats.get(matIndex));
            Map<String, Object> pbr = m == null ? null : Json.obj(m.get("pbrMetallicRoughness"));
            if (pbr != null) {
                double[] c = Json.nums(pbr.get("baseColorFactor"), 4);
                if (c != null) argb = pack(c);
                Map<String, Object> bct = Json.obj(pbr.get("baseColorTexture"));
                if (bct != null) {
                    int ti = (int) Json.num(bct.get("index"), -1);
                    List<Object> texs = Json.arr(root.get("textures"));
                    if (texs != null && ti >= 0 && ti < texs.size()) {
                        Map<String, Object> t = Json.obj(texs.get(ti));
                        if (t != null) imageIndex = (int) Json.num(t.get("source"), -1);
                    }
                }
            }
        }
        String key = imageIndex >= 0 ? "img:" + imageIndex : "col:" + argb;
        Integer slot = texSlots.get(key);
        if (slot != null) return slot;
        byte[] png = imageIndex >= 0 ? image(imageIndex) : Imgs.solid(argb);
        int s = mesh.addTexture(png);
        texSlots.put(key, s);
        return s;
    }

    private static int pack(double[] c) {
        int r = clamp(c[0]), g = clamp(c[1]), b = clamp(c[2]), a = clamp(c[3]);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int clamp(double v) {
        return (int) Math.round(Math.max(0, Math.min(1, v)) * 255);
    }

    private byte[] image(int index) throws SkinException {
        List<Object> imgs = Json.arr(root.get("images"));
        if (imgs == null || index >= imgs.size()) throw new SkinException("В glTF нет изображения №" + index + ".");
        Map<String, Object> im = Json.obj(imgs.get(index));
        if (im == null) throw new SkinException("Повреждён список images.");
        String uri = Json.str(im.get("uri"));
        byte[] raw;
        if (uri != null) {
            raw = readUri(uri);
        } else {
            int bv = (int) Json.num(im.get("bufferView"), -1);
            raw = viewBytes(bv);
        }
        return Imgs.toPng(raw);
    }

    private byte[] viewBytes(int bv) throws SkinException {
        Map<String, Object> v = view(bv);
        int buf = (int) Json.num(v.get("buffer"), 0);
        int off = (int) Json.num(v.get("byteOffset"), 0);
        int len = (int) Json.num(v.get("byteLength"), 0);
        byte[] b = buffer(buf);
        if (off < 0 || len < 0 || off + len > b.length) throw new SkinException("glTF: bufferView выходит за границы буфера.");
        return java.util.Arrays.copyOfRange(b, off, off + len);
    }

    private Map<String, Object> view(int bv) throws SkinException {
        List<Object> views = Json.arr(root.get("bufferViews"));
        Map<String, Object> v = views == null || bv < 0 || bv >= views.size() ? null : Json.obj(views.get(bv));
        if (v == null) throw new SkinException("glTF: нет bufferView №" + bv + ".");
        return v;
    }

    private byte[] buffer(int i) throws SkinException {
        if (i < 0 || i >= buffers.size()) throw new SkinException("glTF: нет буфера №" + i + ".");
        return buffers.get(i);
    }

    private Map<String, Object> accessor(int ai) throws SkinException {
        List<Object> acc = Json.arr(root.get("accessors"));
        Map<String, Object> a = acc == null || ai < 0 || ai >= acc.size() ? null : Json.obj(acc.get(ai));
        if (a == null) throw new SkinException("glTF: нет accessor №" + ai + ".");
        return a;
    }

    private static int compsOf(String type) throws SkinException {
        return switch (type == null ? "" : type) {
            case "SCALAR" -> 1;
            case "VEC2" -> 2;
            case "VEC3" -> 3;
            case "VEC4" -> 4;
            default -> throw new SkinException("glTF: неподдерживаемый тип данных " + type + ".");
        };
    }

    private static int sizeOf(int ct) throws SkinException {
        return switch (ct) {
            case 5120, 5121 -> 1;
            case 5122, 5123 -> 2;
            case 5125, 5126 -> 4;
            default -> throw new SkinException("glTF: неподдерживаемый тип компонента " + ct + ".");
        };
    }

    private double component(ByteBuffer b, int pos, int ct, boolean norm) {
        switch (ct) {
            case 5126:
                return b.getFloat(pos);
            case 5121: {
                int v = b.get(pos) & 0xFF;
                return norm ? v / 255.0 : v;
            }
            case 5120: {
                int v = b.get(pos);
                return norm ? Math.max(v / 127.0, -1) : v;
            }
            case 5123: {
                int v = b.getShort(pos) & 0xFFFF;
                return norm ? v / 65535.0 : v;
            }
            case 5122: {
                int v = b.getShort(pos);
                return norm ? Math.max(v / 32767.0, -1) : v;
            }
            default:
                return b.getInt(pos) & 0xFFFFFFFFL;
        }
    }

    private float[] readFloats(int ai, int want) throws SkinException {
        Map<String, Object> a = accessor(ai);
        int comps = compsOf(Json.str(a.get("type")));
        if (comps != want) throw new SkinException("glTF: неожиданный тип данных атрибута.");
        int ct = (int) Json.num(a.get("componentType"), 5126);
        int count = (int) Json.num(a.get("count"), 0);
        boolean norm = Boolean.TRUE.equals(a.get("normalized"));
        if (a.get("bufferView") == null) return new float[count * comps];
        Map<String, Object> v = view((int) Json.num(a.get("bufferView"), -1));
        byte[] buf = buffer((int) Json.num(v.get("buffer"), 0));
        int base = (int) Json.num(v.get("byteOffset"), 0) + (int) Json.num(a.get("byteOffset"), 0);
        int stride = (int) Json.num(v.get("byteStride"), 0);
        int cs = sizeOf(ct);
        if (stride == 0) stride = cs * comps;
        if (count < 0 || count > 4_000_000) throw new SkinException("glTF: слишком много вершин.");
        long last = (long) base + (long) (count - 1) * stride + (long) comps * cs;
        if (count > 0 && (base < 0 || last > buf.length)) throw new SkinException("glTF: данные выходят за границы буфера.");
        ByteBuffer bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
        float[] out = new float[count * comps];
        for (int k = 0; k < count; k++) {
            for (int c = 0; c < comps; c++) out[k * comps + c] = (float) component(bb, base + k * stride + c * cs, ct, norm);
        }
        return out;
    }

    private int[] readIndices(int ai) throws SkinException {
        Map<String, Object> a = accessor(ai);
        int ct = (int) Json.num(a.get("componentType"), 5125);
        int count = (int) Json.num(a.get("count"), 0);
        if (count < 0 || count > 12_000_000) throw new SkinException("glTF: слишком много индексов.");
        Map<String, Object> v = view((int) Json.num(a.get("bufferView"), -1));
        byte[] buf = buffer((int) Json.num(v.get("buffer"), 0));
        int base = (int) Json.num(v.get("byteOffset"), 0) + (int) Json.num(a.get("byteOffset"), 0);
        int cs = sizeOf(ct);
        int stride = (int) Json.num(v.get("byteStride"), 0);
        if (stride == 0) stride = cs;
        long last = (long) base + (long) (count - 1) * stride + cs;
        if (count > 0 && (base < 0 || last > buf.length)) throw new SkinException("glTF: индексы выходят за границы буфера.");
        ByteBuffer bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
        int[] out = new int[count];
        for (int k = 0; k < count; k++) out[k] = (int) component(bb, base + k * stride, ct, false);
        return out;
    }
}
