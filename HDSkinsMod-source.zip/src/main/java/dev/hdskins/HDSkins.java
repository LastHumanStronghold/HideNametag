package dev.hdskins;

import net.minecraftforge.fml.common.Mod;

/**
 * HDSkins - система скинов с поддержкой HD. Один мод: ставится на сервер и (для тех, кто хочет видеть скины) клиентам.
 * Скины передаются по самому игровому соединению, отдельные порты и сторонние моды не нужны.
 */
@Mod(HDSkins.MODID)
public final class HDSkins {
    public static final String MODID = "hdskins";

    public HDSkins() {
        Net.register();
    }
}
