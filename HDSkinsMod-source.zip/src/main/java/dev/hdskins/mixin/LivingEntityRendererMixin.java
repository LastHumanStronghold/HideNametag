package dev.hdskins.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.hdskins.ClientModels;
import dev.hdskins.ClientSkins;
import net.minecraft.client.renderer.MultiBufferSource;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Для скинов с полупрозрачными пикселями рисуем игрока с прозрачностью (обычный рендер умеет только
 * "есть пиксель / нет пикселя"). require = 0: если вдруг не удастся встроиться, мод всё равно работает.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true, require = 0)
    private void hdskins$renderType(LivingEntity entity, boolean bodyVisible, boolean translucent, boolean glowing,
                                    CallbackInfoReturnable<RenderType> cir) {
        if (!bodyVisible || translucent || glowing || !(entity instanceof AbstractClientPlayer player)) return;
        if (!ClientSkins.isTranslucent(player.getUUID())) return;
        ResourceLocation tex = ClientSkins.textureFor(player.getUUID());
        if (tex != null) cir.setReturnValue(RenderType.entityTranslucent(tex));
    }

    /**
     * Игроку выдана 3D-модель: рисуем её вместо обычного тела (в том числе брони, предметов в руках, плаща) и
     * сами дорисовываем имя над головой. Пока модель не скачана или игрок невидим, работает обычный рендер.
     */
    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void hdskins$body(LivingEntity entity, float yaw, float partialTick, PoseStack ps, MultiBufferSource buffers,
                              int light, CallbackInfo ci) {
        if (!(entity instanceof AbstractClientPlayer player) || player.isInvisible() || player.isSpectator()) return;
        ClientModels.Body body = ClientSkins.bodyFor(player.getUUID());
        if (body == null) return;
        ClientModels.render(body, player, partialTick, ps, buffers, light);
        EntityRendererAccess acc = (EntityRendererAccess) (Object) this;
        if (acc.hdskins$shouldShowName(entity)) {
            acc.hdskins$renderNameTag(entity, entity.getDisplayName(), ps, buffers, light);
        }
        ci.cancel();
    }
}
