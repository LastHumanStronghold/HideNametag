package dev.hdskins.mixin;

import dev.hdskins.ClientSkins;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.ResourceLocation;
import java.util.UUID;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Подменяет скин игрока на уровне данных об игроке (PlayerInfo), поэтому он меняется везде:
 * на модели, в руке от первого лица, в списке игроков. Ничего поверх не рисуется.
 */
@Mixin(PlayerInfo.class)
public abstract class PlayerInfoMixin {
    @Inject(method = "getSkinLocation", at = @At("HEAD"), cancellable = true)
    private void hdskins$skin(CallbackInfoReturnable<ResourceLocation> cir) {
        ResourceLocation rl = ClientSkins.textureFor(((PlayerInfo) (Object) this).getProfile().getId());
        if (rl != null) cir.setReturnValue(rl);
    }

    /** Плащ: если выключен - не показываем никакой; если поставлен модом - показываем его; иначе обычный. */
    @Inject(method = "getCapeLocation", at = @At("HEAD"), cancellable = true, require = 0)
    private void hdskins$cape(CallbackInfoReturnable<ResourceLocation> cir) {
        UUID id = ((PlayerInfo) (Object) this).getProfile().getId();
        if (ClientSkins.capeHidden(id)) {
            cir.setReturnValue(null);
            return;
        }
        ResourceLocation rl = ClientSkins.capeFor(id);
        if (rl != null) cir.setReturnValue(rl);
    }

    @Inject(method = "getModelName", at = @At("HEAD"), cancellable = true)
    private void hdskins$model(CallbackInfoReturnable<String> cir) {
        String model = ClientSkins.modelFor(((PlayerInfo) (Object) this).getProfile().getId());
        if (model != null) cir.setReturnValue(model);
    }
}
