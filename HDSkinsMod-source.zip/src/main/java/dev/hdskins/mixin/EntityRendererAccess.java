package dev.hdskins.mixin;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Доступ к защищённым методам рисования имени над игроком. */
@Mixin(EntityRenderer.class)
public interface EntityRendererAccess {
    @Invoker("shouldShowName")
    boolean hdskins$shouldShowName(Entity entity);

    @Invoker("renderNameTag")
    void hdskins$renderNameTag(Entity entity, Component name, PoseStack poseStack, MultiBufferSource buffers, int light);
}
