package dev.hdskins;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Клиентская часть: какой игрок в каком скине, скачивание файлов с сервера, кэш на диске и загрузка текстур.
 * Все вызовы приходят в главном потоке клиента (через enqueueWork), поэтому текстуры можно регистрировать сразу.
 */
@OnlyIn(Dist.CLIENT)
public final class ClientSkins {
    private static final Logger LOGGER = LogUtils.getLogger();

    public record Assign(String skinHash, boolean slim, String capeHash, boolean capeHidden, String bodyHash) {
    }

    private static final Map<UUID, Assign> ASSIGN = new ConcurrentHashMap<>();
    private static final Map<String, ResourceLocation> TEXTURES = new ConcurrentHashMap<>();
    private static final Set<String> PENDING = ConcurrentHashMap.newKeySet();
    /** Хэши скинов с полупрозрачными пикселями на основных слоях тела: их рисуем «прозрачным» способом. */
    private static final Set<String> TRANSLUCENT = ConcurrentHashMap.newKeySet();
    private static final ChunkAssembler ASSEMBLER = new ChunkAssembler();

    private ClientSkins() {
    }

    // ------------------------------------------------------------------ для рендера

    public static Assign get(UUID player) {
        return ASSIGN.get(player);
    }

    public static ResourceLocation texture(String hash) {
        return TEXTURES.get(hash);
    }

    /** Текстура назначенного игроку скина, если она уже загружена; иначе null (тогда работает обычный скин). */
    public static ResourceLocation textureFor(UUID player) {
        Assign a = ASSIGN.get(player);
        return a == null || a.skinHash().isEmpty() ? null : TEXTURES.get(a.skinHash());
    }

    /** Загруженная 3D-модель тела игрока или null (тогда рисуется обычное тело). */
    public static ClientModels.Body bodyFor(UUID player) {
        Assign a = ASSIGN.get(player);
        return a == null || a.bodyHash().isEmpty() ? null : ClientModels.get(a.bodyHash());
    }

    /** true, если плащ игрока выключен командой /hdskin cape off. */
    public static boolean capeHidden(UUID player) {
        Assign a = ASSIGN.get(player);
        return a != null && a.capeHidden();
    }

    /** Текстура плаща, поставленного модом (и не выключенного), если она уже загружена; иначе null. */
    public static ResourceLocation capeFor(UUID player) {
        Assign a = ASSIGN.get(player);
        return a == null || a.capeHidden() || a.capeHash().isEmpty() ? null : TEXTURES.get(a.capeHash());
    }

    /** true, если у назначенного игроку скина есть полупрозрачные пиксели (нужен рендер с прозрачностью). */
    public static boolean isTranslucent(UUID player) {
        Assign a = ASSIGN.get(player);
        return a != null && TRANSLUCENT.contains(a.skinHash());
    }

    /** "slim" / "default" для назначенного и уже загруженного скина; иначе null. */
    public static String modelFor(UUID player) {
        Assign a = ASSIGN.get(player);
        if (a == null || a.skinHash().isEmpty() || !TEXTURES.containsKey(a.skinHash())) return null;
        return a.slim() ? "slim" : "default";
    }

    // ------------------------------------------------------------------ пакеты

    public static void onAssign(Net.AssignPacket m) {
        boolean skin = Util.HASH.matcher(m.skinHash()).matches();
        boolean cape = Util.HASH.matcher(m.capeHash()).matches();
        boolean body = Util.HASH.matcher(m.bodyHash()).matches();
        if (!skin && !cape && !body && !m.capeHidden()) {
            ASSIGN.remove(m.player());
            return;
        }
        ASSIGN.put(m.player(), new Assign(skin ? m.skinHash() : "", m.slim(), cape ? m.capeHash() : "", m.capeHidden(),
                body ? m.bodyHash() : ""));
        if (body) ensureLoaded(m.bodyHash());
        if (skin) ensureLoaded(m.skinHash());
        if (cape && !m.capeHidden()) ensureLoaded(m.capeHash());
    }

    public static void onChunk(Net.ChunkPacket m) {
        if (!PENDING.contains(m.hash())) return; // мы этот файл не запрашивали
        byte[] done;
        try {
            done = ASSEMBLER.accept(m.hash(), m.index(), m.total(), m.data());
        } catch (IllegalArgumentException e) {
            LOGGER.warn("HDSkins: получен некорректный скин ({}), отбрасываю", e.getMessage());
            PENDING.remove(m.hash());
            return;
        }
        if (done == null) return;
        try {
            Path dir = cacheDir();
            Files.createDirectories(dir);
            Files.write(dir.resolve(m.hash() + ".bin"), done);
        } catch (IOException e) {
            LOGGER.warn("HDSkins: не удалось записать кэш скина", e);
        }
        accept(m.hash(), done);
        PENDING.remove(m.hash());
    }

    /** При выходе с сервера забываем назначения (загруженные текстуры остаются в памяти). */
    public static void reset() {
        ASSIGN.clear();
        PENDING.clear();
        ASSEMBLER.clear();
    }

    // ------------------------------------------------------------------ загрузка

    private static void ensureLoaded(String hash) {
        if (TEXTURES.containsKey(hash) || ClientModels.has(hash) || !PENDING.add(hash)) return;
        Path cached = cacheDir().resolve(hash + ".bin");
        if (Files.isRegularFile(cached)) {
            try {
                byte[] d = Files.readAllBytes(cached);
                if (Util.sha256(d).equals(hash)) {
                    accept(hash, d);
                    PENDING.remove(hash);
                    return;
                }
            } catch (IOException ignored) {
                // перекачаем с сервера
            }
        }
        Net.CHANNEL.sendToServer(new Net.RequestPacket(hash));
    }

    private static Path cacheDir() {
        return FMLPaths.GAMEDIR.get().resolve("hdskins-cache");
    }

    /** Пришедший файл - либо PNG (скин/плащ), либо 3D-модель; определяем по началу данных. */
    private static void accept(String hash, byte[] data) {
        if (ModelCodec.isModelBlob(data)) ClientModels.load(hash, data);
        else upload(hash, data);
    }

    private static void upload(String hash, byte[] data) {
        NativeImage img = null;
        try {
            img = NativeImage.read(new ByteArrayInputStream(data));
            int w = img.getWidth();
            boolean cape = w == img.getHeight() * 2;
            if (w < 64 || w > SkinStore.MAX_RESOLUTION || w % 64 != 0 || (!cape && w != img.getHeight())) return;
            // Прозрачность сохраняем как есть (ванильная игра принудительно делает основные слои непрозрачными).
            // Полностью прозрачные пиксели отбрасывает обычный рендер; если есть полупрозрачные - включаем
            // рендер с прозрачностью (см. LivingEntityRendererMixin).
            int s = w / 64;
            if (!cape && (hasPartialAlpha(img, 0, 0, 32 * s, 16 * s)
                    || hasPartialAlpha(img, 0, 16 * s, 64 * s, 32 * s)
                    || hasPartialAlpha(img, 16 * s, 48 * s, 48 * s, 64 * s))) {
                TRANSLUCENT.add(hash);
            }
            DynamicTexture tex = new DynamicTexture(img); // текстура забирает изображение себе
            img = null;
            ResourceLocation rl = new ResourceLocation(HDSkins.MODID, (cape ? "cape/" : "skin/") + hash);
            Minecraft.getInstance().getTextureManager().register(rl, tex);
            TEXTURES.put(hash, rl);
        } catch (IOException | RuntimeException e) {
            LOGGER.warn("HDSkins: не удалось загрузить текстуру скина", e);
        } finally {
            if (img != null) img.close();
        }
    }

    /** Есть ли в области (основной слой тела) пиксели с альфой строго между "почти прозрачно" и "почти непрозрачно". */
    private static boolean hasPartialAlpha(NativeImage img, int x0, int y0, int x1, int y1) {
        for (int y = y0; y < y1; y++) {
            for (int x = x0; x < x1; x++) {
                int alpha = (img.getPixelRGBA(x, y) >>> 24) & 0xFF;
                if (alpha > 16 && alpha < 240) return true;
            }
        }
        return false;
    }
}
