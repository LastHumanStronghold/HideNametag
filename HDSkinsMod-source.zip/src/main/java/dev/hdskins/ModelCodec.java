package dev.hdskins;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Set;

/**
 * Вход: файл модели любого поддерживаемого формата. Выход: компактный двоичный формат "HDM1", который сервер
 * отдаёт клиентам. Здесь же загрузка по расширению и приведение модели к размеру игрока.
 */
public final class ModelCodec {
    public static final int MAGIC = 0x48444D31; // "HDM1"
    public static final double PLAYER_HEIGHT = 1.8;
    public static final Set<String> EXTENSIONS = Set.of("glb", "gltf", "obj", "bbmodel", "json");

    private ModelCodec() {
    }

    public static String extension(String fileName) {
        int d = fileName.lastIndexOf('.');
        return d < 0 ? "" : fileName.substring(d + 1).toLowerCase(Locale.ROOT);
    }

    /** Читает файл модели (формат по расширению). */
    public static Mesh load(Path file) throws SkinException {
        try {
            return loadUnsafe(file);
        } catch (RuntimeException e) {
            throw new SkinException("Файл модели повреждён или содержит неподдерживаемые данные.");
        }
    }

    private static Mesh loadUnsafe(Path file) throws SkinException {
        return switch (extension(file.getFileName().toString())) {
            case "glb", "gltf" -> GltfLoader.load(file);
            case "obj" -> ObjLoader.load(file);
            case "bbmodel" -> BlockbenchLoader.loadBbmodel(file);
            case "json" -> BlockbenchLoader.loadMcJson(file);
            default -> throw new SkinException("Неподдерживаемый формат: " + file.getFileName());
        };
    }

    /**
     * Ставит модель «ногами на землю», по центру, высотой 1.8 блока * scale.
     *
     * @param extraRotation поворот вокруг Y сверх стандартного для формата (градусы)
     * @param yOffset       сдвиг по высоте (блоки)
     */
    public static void normalize(Mesh m, double extraRotation, double scale, double yOffset) throws SkinException {
        Xf rot = Xf.rotate(1, m.frontRotation + extraRotation);
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, minZ = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        for (Mesh.Part p : m.parts) {
            for (int i = 0; i < p.pos.length; i += 3) {
                double[] r = rot.pt(p.pos[i], p.pos[i + 1], p.pos[i + 2]);
                p.pos[i] = (float) r[0];
                p.pos[i + 1] = (float) r[1];
                p.pos[i + 2] = (float) r[2];
                minX = Math.min(minX, r[0]);
                maxX = Math.max(maxX, r[0]);
                minY = Math.min(minY, r[1]);
                maxY = Math.max(maxY, r[1]);
                minZ = Math.min(minZ, r[2]);
                maxZ = Math.max(maxZ, r[2]);
                if (Double.isNaN(r[0] + r[1] + r[2]) || Double.isInfinite(r[0] + r[1] + r[2])) {
                    throw new SkinException("В модели некорректные координаты.");
                }
            }
            for (int i = 0; i < p.nrm.length; i += 3) {
                double[] r = rot.dir(p.nrm[i], p.nrm[i + 1], p.nrm[i + 2]);
                p.nrm[i] = (float) r[0];
                p.nrm[i + 1] = (float) r[1];
                p.nrm[i + 2] = (float) r[2];
            }
        }
        double height = maxY - minY;
        if (height < 1e-9) throw new SkinException("У модели нулевая высота.");
        double s = PLAYER_HEIGHT * scale / height;
        double cx = (minX + maxX) / 2, cz = (minZ + maxZ) / 2;
        for (Mesh.Part p : m.parts) {
            for (int i = 0; i < p.pos.length; i += 3) {
                p.pos[i] = (float) ((p.pos[i] - cx) * s);
                p.pos[i + 1] = (float) ((p.pos[i + 1] - minY) * s + yOffset);
                p.pos[i + 2] = (float) ((p.pos[i + 2] - cz) * s);
            }
        }
    }

    // ------------------------------------------------------------------ двоичный формат

    public static byte[] encode(Mesh m) throws SkinException {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            DataOutputStream o = new DataOutputStream(bo);
            o.writeInt(MAGIC);
            o.writeByte(m.textures.size());
            for (byte[] t : m.textures) {
                o.writeInt(t.length);
                o.write(t);
            }
            o.writeShort(m.parts.size());
            for (Mesh.Part p : m.parts) {
                o.writeByte(p.texture);
                int verts = p.pos.length / 3;
                o.writeInt(verts);
                for (int v = 0; v < verts; v++) {
                    o.writeFloat(p.pos[v * 3]);
                    o.writeFloat(p.pos[v * 3 + 1]);
                    o.writeFloat(p.pos[v * 3 + 2]);
                    o.writeFloat(p.uv[v * 2]);
                    o.writeFloat(p.uv[v * 2 + 1]);
                    o.writeByte(snorm(p.nrm[v * 3]));
                    o.writeByte(snorm(p.nrm[v * 3 + 1]));
                    o.writeByte(snorm(p.nrm[v * 3 + 2]));
                }
            }
            o.flush();
            byte[] out = bo.toByteArray();
            if (out.length > ChunkAssembler.MAX_BYTES) {
                throw new SkinException("Модель после обработки весит " + out.length / 1024 / 1024
                        + " МБ (максимум " + ChunkAssembler.MAX_BYTES / 1024 / 1024 + " МБ). Уменьшите текстуры или число полигонов.");
            }
            return out;
        } catch (IOException e) {
            throw new SkinException("Ошибка упаковки модели.");
        }
    }

    private static int snorm(float v) {
        return Math.round(Math.max(-1f, Math.min(1f, v)) * 127f);
    }

    public static boolean isModelBlob(byte[] d) {
        return d.length >= 4 && ((d[0] & 0xFF) << 24 | (d[1] & 0xFF) << 16 | (d[2] & 0xFF) << 8 | (d[3] & 0xFF)) == MAGIC;
    }

    /** Разбор данных, полученных от сервера (клиент им не доверяет: всё проверяется). */
    public static Mesh decode(byte[] d) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(d));
        if (in.readInt() != MAGIC) throw new IOException("bad magic");
        Mesh m = new Mesh();
        int nt = in.readUnsignedByte();
        if (nt > Mesh.MAX_TEXTURES) throw new IOException("too many textures");
        for (int i = 0; i < nt; i++) {
            int len = in.readInt();
            if (len < 0 || len > in.available()) throw new IOException("bad texture");
            byte[] t = new byte[len];
            in.readFully(t);
            m.textures.add(t);
        }
        int np = in.readUnsignedShort();
        if (np > 4096) throw new IOException("too many parts");
        int total = 0;
        for (int i = 0; i < np; i++) {
            Mesh.Part p = new Mesh.Part();
            p.texture = in.readUnsignedByte();
            if (p.texture >= nt) throw new IOException("bad texture index");
            int verts = in.readInt();
            if (verts < 0 || verts % 3 != 0) throw new IOException("bad vertex count");
            total += verts / 3;
            if (total > Mesh.MAX_TRIANGLES || (long) verts * 23 > in.available()) throw new IOException("too big");
            p.pos = new float[verts * 3];
            p.uv = new float[verts * 2];
            p.nrm = new float[verts * 3];
            for (int v = 0; v < verts; v++) {
                p.pos[v * 3] = in.readFloat();
                p.pos[v * 3 + 1] = in.readFloat();
                p.pos[v * 3 + 2] = in.readFloat();
                p.uv[v * 2] = in.readFloat();
                p.uv[v * 2 + 1] = in.readFloat();
                p.nrm[v * 3] = in.readByte() / 127f;
                p.nrm[v * 3 + 1] = in.readByte() / 127f;
                p.nrm[v * 3 + 2] = in.readByte() / 127f;
            }
            m.parts.add(p);
        }
        return m;
    }
}
