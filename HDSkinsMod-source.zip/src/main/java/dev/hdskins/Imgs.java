package dev.hdskins;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.MemoryCacheImageInputStream;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.Locale;
import java.util.stream.Stream;

/** Работа с картинками и файлами рядом с моделью (без Minecraft). */
final class Imgs {
    static final int MAX_SOURCE_SIDE = 8192;
    static final int MAX_SIDE = 2048;
    static final long MAX_FILE = 64L * 1024 * 1024;

    private Imgs() {
    }

    /** Любую поддерживаемую картинку (PNG, JPG, ...) -> PNG не больше 2048 пикселей по стороне. */
    static byte[] toPng(byte[] data) throws SkinException {
        ImageReader reader = null;
        try (ImageInputStream in = new MemoryCacheImageInputStream(new ByteArrayInputStream(data))) {
            Iterator<ImageReader> it = ImageIO.getImageReaders(in);
            if (!it.hasNext()) throw new SkinException("Неизвестный формат текстуры (нужен PNG или JPG).");
            reader = it.next();
            reader.setInput(in, true, true);
            int w = reader.getWidth(0), h = reader.getHeight(0);
            if (w < 1 || h < 1 || w > MAX_SOURCE_SIDE || h > MAX_SOURCE_SIDE) {
                throw new SkinException("Текстура " + w + "x" + h + " слишком большая (максимум " + MAX_SOURCE_SIDE + ").");
            }
            BufferedImage img = reader.read(0);
            while (img.getWidth() > MAX_SIDE || img.getHeight() > MAX_SIDE) {
                int nw = Math.max(1, img.getWidth() / 2), nh = Math.max(1, img.getHeight() / 2);
                BufferedImage s = new BufferedImage(nw, nh, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = s.createGraphics();
                g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g.drawImage(img, 0, 0, nw, nh, null);
                g.dispose();
                img = s;
            }
            BufferedImage argb = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = argb.createGraphics();
            g.drawImage(img, 0, 0, null);
            g.dispose();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            ImageIO.write(argb, "png", bo);
            return bo.toByteArray();
        } catch (IOException | RuntimeException e) {
            throw new SkinException("Текстура повреждена или не читается.");
        } finally {
            if (reader != null) reader.dispose();
        }
    }

    /** PNG 1x1 заданного цвета (для материалов без текстуры). */
    static byte[] solid(int argb) {
        try {
            BufferedImage img = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
            img.setRGB(0, 0, argb);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            ImageIO.write(img, "png", bo);
            return bo.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    static byte[] readLimited(Path p) throws SkinException {
        try {
            if (Files.size(p) > MAX_FILE) throw new SkinException("Файл " + p.getFileName() + " слишком большой.");
            return Files.readAllBytes(p);
        } catch (IOException e) {
            throw new SkinException("Не удалось прочитать " + p.getFileName() + ": " + e.getMessage());
        }
    }

    /**
     * Ищет файл рядом с моделью по имени (папки и регистр игнорируются: ссылки из Windows-программ).
     * Выйти за пределы папки нельзя. null, если не найден.
     */
    static Path findNear(Path dir, String ref) {
        if (ref == null) return null;
        String name = ref.replace('\\', '/');
        name = name.substring(name.lastIndexOf('/') + 1);
        if (name.isEmpty()) return null;
        try (Stream<Path> st = Files.list(dir)) {
            String want = name.toLowerCase(Locale.ROOT);
            return st.filter(Files::isRegularFile)
                    .filter(f -> f.getFileName().toString().toLowerCase(Locale.ROOT).equals(want))
                    .findFirst().orElse(null);
        } catch (IOException e) {
            return null;
        }
    }

    /** Как findNear, но если у имени нет подходящего файла, пробует добавить расширения .png/.jpg. */
    static Path findImageNear(Path dir, String ref) {
        Path p = findNear(dir, ref);
        if (p != null) return p;
        for (String ext : new String[]{".png", ".jpg", ".jpeg"}) {
            p = findNear(dir, ref + ext);
            if (p != null) return p;
        }
        return null;
    }
}
