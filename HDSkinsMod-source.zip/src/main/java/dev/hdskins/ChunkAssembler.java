package dev.hdskins;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Передача PNG по сети кусками (один пакет Minecraft ограничен по размеру) и сборка на клиенте.
 * Не зависит от Minecraft. Клиент не доверяет серверу: итог проверяется по SHA-256, размеры ограничены.
 */
public final class ChunkAssembler {
    public static final int CHUNK_SIZE = 30_000;
    public static final int MAX_BYTES = 8 * 1024 * 1024;
    private static final int MAX_CHUNKS = MAX_BYTES / CHUNK_SIZE + 2;

    private static final class Partial {
        final byte[][] parts;
        int received;
        long size;

        Partial(int n) {
            parts = new byte[n][];
        }
    }

    private final Map<String, Partial> partial = new HashMap<>();

    public static List<byte[]> split(byte[] data) {
        List<byte[]> out = new ArrayList<>();
        for (int pos = 0; pos < data.length; pos += CHUNK_SIZE) {
            int len = Math.min(CHUNK_SIZE, data.length - pos);
            byte[] c = new byte[len];
            System.arraycopy(data, pos, c, 0, len);
            out.add(c);
        }
        return out;
    }

    /**
     * Принимает кусок.
     *
     * @return полный файл, когда все куски получены и хэш совпал; иначе null (ждём остальные)
     * @throws IllegalArgumentException кусок некорректен или итог не совпал с хэшем (состояние для hash сбрасывается)
     */
    public synchronized byte[] accept(String hash, int index, int total, byte[] data) {
        if (total < 1 || total > MAX_CHUNKS || index < 0 || index >= total || data.length > CHUNK_SIZE) {
            partial.remove(hash);
            throw new IllegalArgumentException("bad chunk");
        }
        Partial p = partial.computeIfAbsent(hash, h -> new Partial(total));
        if (p.parts.length != total) {
            partial.remove(hash);
            throw new IllegalArgumentException("inconsistent total");
        }
        if (p.parts[index] == null) {
            p.parts[index] = data;
            p.received++;
            p.size += data.length;
            if (p.size > MAX_BYTES) {
                partial.remove(hash);
                throw new IllegalArgumentException("too big");
            }
        }
        if (p.received < total) return null;

        partial.remove(hash);
        byte[] out = new byte[(int) p.size];
        int pos = 0;
        for (byte[] b : p.parts) {
            System.arraycopy(b, 0, out, pos, b.length);
            pos += b.length;
        }
        if (!Util.sha256(out).equals(hash)) throw new IllegalArgumentException("hash mismatch");
        return out;
    }

    public synchronized void clear() {
        partial.clear();
    }
}
