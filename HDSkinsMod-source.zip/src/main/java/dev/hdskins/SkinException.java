package dev.hdskins;

/** Ошибка с готовым текстом для игрока/админа. */
public final class SkinException extends Exception {
    private static final long serialVersionUID = 1L;

    public SkinException(String message) {
        super(message);
    }
}
