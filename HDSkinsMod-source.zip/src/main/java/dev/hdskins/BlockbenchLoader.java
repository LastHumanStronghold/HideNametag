package dev.hdskins;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Блочные модели: проект Blockbench (.bbmodel: кубы, меши, группы с поворотами) и обычный JSON модели Minecraft
 * (.json: elements/faces/textures). Статичная поза, без анимаций.
 */
final class BlockbenchLoader {
    private static final String[] FACES = {"north", "east", "south", "west", "up", "down"};

    /** Вершины граней как в Minecraft (индексы 0/1: min/max по X, Y, Z). {x,y,z} для 4 углов. */
    private static final int[][][] CORNERS = {
            // north
            {{1, 1, 0}, {1, 0, 0}, {0, 0, 0}, {0, 1, 0}},
            // east
            {{1, 1, 1}, {1, 0, 1}, {1, 0, 0}, {1, 1, 0}},
            // south
            {{0, 1, 1}, {0, 0, 1}, {1, 0, 1}, {1, 1, 1}},
            // west
            {{0, 1, 0}, {0, 0, 0}, {0, 0, 1}, {0, 1, 1}},
            // up
            {{0, 1, 0}, {0, 1, 1}, {1, 1, 1}, {1, 1, 0}},
            // down
            {{0, 0, 1}, {0, 0, 0}, {1, 0, 0}, {1, 0, 1}}};

    private final Mesh mesh = new Mesh();
    private final Path dir;

    private BlockbenchLoader(Path dir) {
        this.dir = dir;
    }

    // ------------------------------------------------------------------ .bbmodel

    private int[] texSlot = new int[0];
    private double[] texW = new double[0], texH = new double[0];
    private int grayFallback = -1;
    private double resW = 16, resH = 16;
    private Map<String, Map<String, Object>> byUuid = new HashMap<>();

    static Mesh loadBbmodel(Path file) throws SkinException {
        Path dir = file.toAbsolutePath().getParent();
        Object parsed = Json.parse(new String(Imgs.readLimited(file), StandardCharsets.UTF_8));
        Map<String, Object> root = Json.obj(parsed);
        if (root == null || !(root.get("elements") instanceof List)) throw new SkinException("Файл не похож на проект Blockbench.");
        BlockbenchLoader l = new BlockbenchLoader(dir);
        return l.runBb(root);
    }

    private Mesh runBb(Map<String, Object> root) throws SkinException {
        Map<String, Object> res = Json.obj(root.get("resolution"));
        if (res != null) {
            resW = Math.max(1, Json.num(res.get("width"), 16));
            resH = Math.max(1, Json.num(res.get("height"), 16));
        }
        List<Object> texs = Json.arr(root.get("textures"));
        if (texs != null) {
            texSlot = new int[texs.size()];
            texW = new double[texs.size()];
            texH = new double[texs.size()];
            for (int i = 0; i < texs.size(); i++) {
                Map<String, Object> t = Json.obj(texs.get(i));
                texSlot[i] = -1;
                texW[i] = resW;
                texH[i] = resH;
                if (t == null) continue;
                texW[i] = Math.max(1, Json.num(t.get("uv_width"), resW));
                texH[i] = Math.max(1, Json.num(t.get("uv_height"), resH));
                byte[] raw = null;
                String src = Json.str(t.get("source"));
                if (src != null && src.startsWith("data:")) {
                    int c = src.indexOf(',');
                    try {
                        if (c > 0) raw = Base64.getDecoder().decode(src.substring(c + 1).trim());
                    } catch (IllegalArgumentException e) {
                        throw new SkinException("Blockbench: повреждена встроенная текстура.");
                    }
                }
                if (raw == null) {
                    Path p = Imgs.findNear(dir, Json.str(t.get("relative_path")));
                    if (p == null) p = Imgs.findImageNear(dir, Json.str(t.get("name")));
                    if (p != null) raw = Imgs.readLimited(p);
                }
                if (raw != null) texSlot[i] = mesh.addTexture(Imgs.toPng(raw));
            }
        }
        for (Object o : Json.arr(root.get("elements"))) {
            Map<String, Object> e = Json.obj(o);
            if (e == null) continue;
            String id = Json.str(e.get("uuid"));
            if (id != null) byUuid.put(id, e);
        }
        Object outliner = root.get("outliner");
        java.util.Set<String> used = new java.util.HashSet<>();
        if (outliner instanceof List) {
            for (Object n : Json.arr(outliner)) walk(n, Xf.identity(), used, 0);
        }
        for (Object o : Json.arr(root.get("elements"))) { // элементы вне outliner рисуем без группы
            Map<String, Object> e = Json.obj(o);
            if (e == null) continue;
            String id = Json.str(e.get("uuid"));
            if (id == null || !used.contains(id)) element(e, Xf.identity());
        }
        mesh.frontRotation = 180; // в Blockbench перед модели смотрит на север (-Z)
        return mesh.finish();
    }

    private void walk(Object node, Xf parent, java.util.Set<String> used, int depth) throws SkinException {
        if (depth > 64) return;
        if (node instanceof String id) {
            Map<String, Object> e = byUuid.get(id);
            if (e != null) {
                used.add(id);
                element(e, parent);
            }
            return;
        }
        Map<String, Object> g = Json.obj(node);
        if (g == null) return;
        if (Boolean.FALSE.equals(g.get("export")) || Boolean.FALSE.equals(g.get("visibility"))) {
            markUsed(g, used, depth);
            return;
        }
        double[] o = Json.nums(g.get("origin"), 3);
        double[] r = Json.nums(g.get("rotation"), 3);
        Xf local = o == null ? Xf.identity() : Xf.around(eulerZyx(r), o[0], o[1], o[2]);
        Xf cur = parent.mul(local);
        List<Object> ch = Json.arr(g.get("children"));
        if (ch != null) for (Object c : ch) walk(c, cur, used, depth + 1);
    }

    private void markUsed(Map<String, Object> g, java.util.Set<String> used, int depth) {
        List<Object> ch = Json.arr(g.get("children"));
        if (ch == null || depth > 64) return;
        for (Object c : ch) {
            if (c instanceof String id) used.add(id);
            else if (Json.obj(c) != null) markUsed(Json.obj(c), used, depth + 1);
        }
    }

    private static Xf eulerZyx(double[] r) {
        if (r == null) return Xf.identity();
        return Xf.rotate(2, r[2]).mul(Xf.rotate(1, r[1])).mul(Xf.rotate(0, r[0]));
    }

    private void element(Map<String, Object> e, Xf group) throws SkinException {
        if (Boolean.FALSE.equals(e.get("export")) || Boolean.FALSE.equals(e.get("visibility"))) return;
        double[] origin = Json.nums(e.get("origin"), 3);
        if (origin == null) origin = new double[]{0, 0, 0};
        Xf rot = Xf.around(eulerZyx(Json.nums(e.get("rotation"), 3)), origin[0], origin[1], origin[2]);
        Xf xf = group.mul(rot);
        String type = Json.str(e.get("type"));
        if ("mesh".equals(type)) {
            meshElement(e, xf, origin);
            return;
        }
        double[] from = Json.nums(e.get("from"), 3), to = Json.nums(e.get("to"), 3);
        if (from == null || to == null) return;
        double inf = Json.num(e.get("inflate"), 0);
        double[] lo = {from[0] - inf, from[1] - inf, from[2] - inf};
        double[] hi = {to[0] + inf, to[1] + inf, to[2] + inf};
        Map<String, Object> faces = Json.obj(e.get("faces"));
        if (faces == null) return;
        for (int fi = 0; fi < 6; fi++) {
            Map<String, Object> face = Json.obj(faces.get(FACES[fi]));
            if (face == null || !(face.get("texture") instanceof Double td)) continue;
            double[] uv = Json.nums(face.get("uv"), 4);
            if (uv == null) continue;
            int ti = (int) (double) td;
            double w = ti >= 0 && ti < texW.length ? texW[ti] : resW;
            double h = ti >= 0 && ti < texH.length ? texH[ti] : resH;
            int slot = ti >= 0 && ti < texSlot.length ? texSlot[ti] : -1;
            emitFace(fi, lo, hi, xf, slot(slot), new double[]{uv[0] / w, uv[1] / h, uv[2] / w, uv[3] / h},
                    (int) Json.num(face.get("rotation"), 0));
        }
    }

    private int slot(int s) throws SkinException {
        if (s >= 0) return s;
        if (grayFallback < 0) grayFallback = mesh.addTexture(Imgs.solid(0xFFCCCCCC));
        return grayFallback;
    }

    private void emitFace(int fi, double[] lo, double[] hi, Xf xf, int tex, double[] uv, int rotation) throws SkinException {
        double[][] p = new double[4][];
        for (int k = 0; k < 4; k++) {
            int[] c = CORNERS[fi][k];
            p[k] = xf.pt(c[0] == 1 ? hi[0] : lo[0], c[1] == 1 ? hi[1] : lo[1], c[2] == 1 ? hi[2] : lo[2]);
        }
        float[] t = new float[8];
        int shift = ((rotation / 90) % 4 + 4) % 4;
        for (int k = 0; k < 4; k++) {
            int ci = (k + shift) % 4; // как в Minecraft: угол текстуры сдвигается по кругу
            t[k * 2] = (float) (ci == 0 || ci == 1 ? uv[0] : uv[2]);
            t[k * 2 + 1] = (float) (ci == 0 || ci == 3 ? uv[1] : uv[3]);
        }
        mesh.addQuad(tex, p[0], p[1], p[2], p[3], t);
    }

    private void meshElement(Map<String, Object> e, Xf xf, double[] origin) throws SkinException {
        Map<String, Object> verts = Json.obj(e.get("vertices"));
        Map<String, Object> faces = Json.obj(e.get("faces"));
        if (verts == null || faces == null) return;
        for (Object fo : faces.values()) {
            Map<String, Object> f = Json.obj(fo);
            if (f == null) continue;
            List<Object> ids = Json.arr(f.get("vertices"));
            Map<String, Object> uvs = Json.obj(f.get("uv"));
            if (ids == null || ids.size() < 3 || uvs == null) continue;
            int ti = f.get("texture") instanceof Double d ? (int) (double) d : -1;
            double w = ti >= 0 && ti < texW.length ? texW[ti] : resW;
            double h = ti >= 0 && ti < texH.length ? texH[ti] : resH;
            int slot = slot(ti >= 0 && ti < texSlot.length ? texSlot[ti] : -1);
            List<double[]> pts = new ArrayList<>();
            List<float[]> tuv = new ArrayList<>();
            for (Object idObj : ids) {
                String id = Json.str(idObj);
                double[] v = id == null ? null : Json.nums(verts.get(id), 3);
                double[] u = id == null ? null : Json.nums(uvs.get(id), 2);
                if (v == null) continue;
                pts.add(xf.pt(origin[0] + v[0], origin[1] + v[1], origin[2] + v[2]));
                tuv.add(u == null ? new float[]{0, 0} : new float[]{(float) (u[0] / w), (float) (u[1] / h)});
            }
            for (int k = 1; k + 1 < pts.size(); k++) {
                float[] a = tuv.get(0), b = tuv.get(k), c = tuv.get(k + 1);
                mesh.add(slot, pts.get(0), pts.get(k), pts.get(k + 1), new float[]{a[0], a[1], b[0], b[1], c[0], c[1]}, null);
            }
        }
    }

    // ------------------------------------------------------------------ .json (Minecraft)

    static Mesh loadMcJson(Path file) throws SkinException {
        Path dir = file.toAbsolutePath().getParent();
        Map<String, Object> root = Json.obj(Json.parse(new String(Imgs.readLimited(file), StandardCharsets.UTF_8)));
        if (root == null || !(root.get("elements") instanceof List)) {
            throw new SkinException("JSON не похож на модель Minecraft (нет elements).");
        }
        BlockbenchLoader l = new BlockbenchLoader(dir);
        return l.runMc(root, file);
    }

    private Mesh runMc(Map<String, Object> root, Path file) throws SkinException {
        Map<String, Object> textures = Json.obj(root.get("textures"));
        Map<String, Integer> slots = new HashMap<>();
        String fn = file.getFileName().toString();
        String base = fn.substring(0, fn.lastIndexOf('.'));
        for (Object o : Json.arr(root.get("elements"))) {
            Map<String, Object> e = Json.obj(o);
            if (e == null) continue;
            double[] from = Json.nums(e.get("from"), 3), to = Json.nums(e.get("to"), 3);
            Map<String, Object> faces = Json.obj(e.get("faces"));
            if (from == null || to == null || faces == null) continue;
            Xf xf = Xf.identity();
            Map<String, Object> r = Json.obj(e.get("rotation"));
            if (r != null) {
                double[] org = Json.nums(r.get("origin"), 3);
                String axis = Json.str(r.get("axis"));
                if (org != null && axis != null) {
                    int ax = axis.equals("x") ? 0 : axis.equals("y") ? 1 : 2;
                    xf = Xf.around(Xf.rotate(ax, Json.num(r.get("angle"), 0)), org[0], org[1], org[2]);
                }
            }
            for (int fi = 0; fi < 6; fi++) {
                Map<String, Object> face = Json.obj(faces.get(FACES[fi]));
                if (face == null) continue;
                double[] uv = Json.nums(face.get("uv"), 4);
                if (uv == null) uv = defaultUv(fi, from, to);
                int tex = mcTexture(Json.str(face.get("texture")), textures, slots, base);
                emitFace(fi, from, to, xf, tex, new double[]{uv[0] / 16, uv[1] / 16, uv[2] / 16, uv[3] / 16},
                        (int) Json.num(face.get("rotation"), 0));
            }
        }
        mesh.frontRotation = 180; // в блочных моделях перед смотрит на север (-Z)
        return mesh.finish();
    }

    private static double[] defaultUv(int fi, double[] f, double[] t) {
        return switch (fi) {
            case 0 -> new double[]{16 - t[0], 16 - t[1], 16 - f[0], 16 - f[1]};
            case 1 -> new double[]{16 - t[2], 16 - t[1], 16 - f[2], 16 - f[1]};
            case 2 -> new double[]{f[0], 16 - t[1], t[0], 16 - f[1]};
            case 3 -> new double[]{f[2], 16 - t[1], t[2], 16 - f[1]};
            case 4 -> new double[]{f[0], f[2], t[0], t[2]};
            default -> new double[]{f[0], 16 - t[2], t[0], 16 - f[2]};
        };
    }

    private int mcTexture(String ref, Map<String, Object> textures, Map<String, Integer> slots, String base) throws SkinException {
        String key = ref == null ? "" : ref;
        Integer s = slots.get(key);
        if (s != null) return s;
        String value = ref;
        for (int guard = 0; guard < 8 && value != null && value.startsWith("#"); guard++) {
            value = textures == null ? null : Json.str(textures.get(value.substring(1)));
        }
        byte[] png = null;
        if (value != null && !value.startsWith("#")) {
            String name = value.substring(Math.max(value.lastIndexOf('/'), value.lastIndexOf(':')) + 1);
            Path p = Imgs.findImageNear(dir, name);
            if (p != null) png = Imgs.toPng(Imgs.readLimited(p));
        }
        if (png == null) {
            Path p = Imgs.findImageNear(dir, base);
            if (p != null) png = Imgs.toPng(Imgs.readLimited(p));
        }
        if (png == null) png = Imgs.solid(0xFFCCCCCC);
        int slot = mesh.addTexture(png);
        slots.put(key, slot);
        return slot;
    }
}
