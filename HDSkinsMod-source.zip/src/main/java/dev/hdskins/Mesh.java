package dev.hdskins;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Внутреннее представление 3D-модели: набор треугольников (без индексов), сгруппированных по текстуре.
 * Единицы - блоки, Y вверх. Не зависит от Minecraft.
 */
public final class Mesh {
    public static final int MAX_TRIANGLES = 80_000;
    public static final int MAX_TEXTURES = 32;

    /** Треугольники одной текстуры: pos 9, uv 6, nrm 9 чисел на треугольник. */
    public static final class Part {
        public int texture;
        public float[] pos;
        public float[] uv;
        public float[] nrm;

        public int triangles() {
            return pos.length / 9;
        }
    }

    private static final class Buf {
        float[] pos = new float[9 * 64];
        float[] uv = new float[6 * 64];
        float[] nrm = new float[9 * 64];
        int tris;
    }

    /** PNG-файлы текстур. */
    public final List<byte[]> textures = new ArrayList<>();
    public List<Part> parts = new ArrayList<>();
    /** Поворот вокруг Y (градусы), приводящий «перед» исходного формата к «перед» Minecraft (+Z). */
    public double frontRotation;

    private final Map<Integer, Buf> bufs = new LinkedHashMap<>();
    private int total;

    public int addTexture(byte[] png) throws SkinException {
        if (textures.size() >= MAX_TEXTURES) throw new SkinException("Слишком много текстур (максимум " + MAX_TEXTURES + ").");
        textures.add(png);
        return textures.size() - 1;
    }

    /**
     * Добавляет треугольник. p* - вершины (по 3 числа), uv - 6 чисел, n* - нормали вершин или null
     * (тогда считается плоская нормаль).
     */
    public void add(int tex, double[] p0, double[] p1, double[] p2, float[] uv, double[][] n) throws SkinException {
        double ux = p1[0] - p0[0], uy = p1[1] - p0[1], uz = p1[2] - p0[2];
        double vx = p2[0] - p0[0], vy = p2[1] - p0[1], vz = p2[2] - p0[2];
        double cx = uy * vz - uz * vy, cy = uz * vx - ux * vz, cz = ux * vy - uy * vx;
        double len = Math.sqrt(cx * cx + cy * cy + cz * cz);
        if (len < 1e-12) return; // вырожденный треугольник
        if (++total > MAX_TRIANGLES) {
            throw new SkinException("Слишком много треугольников (максимум " + MAX_TRIANGLES + "). Упростите модель.");
        }
        Buf b = bufs.computeIfAbsent(tex, k -> new Buf());
        if (b.tris * 9 + 9 > b.pos.length) {
            b.pos = Arrays.copyOf(b.pos, b.pos.length * 2);
            b.uv = Arrays.copyOf(b.uv, b.uv.length * 2);
            b.nrm = Arrays.copyOf(b.nrm, b.nrm.length * 2);
        }
        int o = b.tris * 9;
        double[][] ps = {p0, p1, p2};
        for (int k = 0; k < 3; k++) {
            b.pos[o + k * 3] = (float) ps[k][0];
            b.pos[o + k * 3 + 1] = (float) ps[k][1];
            b.pos[o + k * 3 + 2] = (float) ps[k][2];
            if (n != null && n[k] != null) {
                b.nrm[o + k * 3] = (float) n[k][0];
                b.nrm[o + k * 3 + 1] = (float) n[k][1];
                b.nrm[o + k * 3 + 2] = (float) n[k][2];
            } else {
                b.nrm[o + k * 3] = (float) (cx / len);
                b.nrm[o + k * 3 + 1] = (float) (cy / len);
                b.nrm[o + k * 3 + 2] = (float) (cz / len);
            }
        }
        System.arraycopy(uv, 0, b.uv, b.tris * 6, 6);
        b.tris++;
    }

    /** Четырёхугольник p0 p1 p2 p3 (по кругу) -> два треугольника. */
    public void addQuad(int tex, double[] p0, double[] p1, double[] p2, double[] p3, float[] uv8) throws SkinException {
        add(tex, p0, p1, p2, new float[]{uv8[0], uv8[1], uv8[2], uv8[3], uv8[4], uv8[5]}, null);
        add(tex, p0, p2, p3, new float[]{uv8[0], uv8[1], uv8[4], uv8[5], uv8[6], uv8[7]}, null);
    }

    /** Завершает сборку: превращает накопленное в parts. */
    public Mesh finish() throws SkinException {
        parts = new ArrayList<>();
        for (Map.Entry<Integer, Buf> e : bufs.entrySet()) {
            Buf b = e.getValue();
            Part p = new Part();
            p.texture = e.getKey();
            p.pos = Arrays.copyOf(b.pos, b.tris * 9);
            p.uv = Arrays.copyOf(b.uv, b.tris * 6);
            p.nrm = Arrays.copyOf(b.nrm, b.tris * 9);
            parts.add(p);
        }
        if (parts.isEmpty()) throw new SkinException("В модели нет ни одного треугольника.");
        return this;
    }

    public int triangles() {
        int n = 0;
        for (Part p : parts) n += p.triangles();
        return n;
    }
}
