package dev.hdskins;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.UUID;
import java.util.function.Supplier;

/**
 * Сетевой канал мода. Версии не согласуются (принимаем любые, в том числе отсутствие мода),
 * поэтому игроки без мода спокойно заходят на сервер с модом и наоборот.
 *
 * Сообщения:
 *   AssignPacket (сервер -> клиент): у игрока UUID такие скин, плащ и модель тела (пустой хэш - нет)
 *   RequestPacket (клиент -> сервер): пришли файл скина с таким хэшем
 *   ChunkPacket (сервер -> клиент): кусок файла (скин, плащ или модель)
 */
public final class Net {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(HDSkins.MODID, "main"),
            () -> PROTOCOL,
            v -> true,
            v -> true);

    private Net() {
    }

    static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, AssignPacket.class, AssignPacket::encode, AssignPacket::decode, AssignPacket::handle);
        CHANNEL.registerMessage(id++, RequestPacket.class, RequestPacket::encode, RequestPacket::decode, RequestPacket::handle);
        CHANNEL.registerMessage(id++, ChunkPacket.class, ChunkPacket::encode, ChunkPacket::decode, ChunkPacket::handle);
    }

    // ------------------------------------------------------------------ сервер -> клиент: назначение

    /** Пустой хэш - «нет»: skinHash - скин, capeHash - плащ, bodyHash - 3D-модель тела. */
    public record AssignPacket(UUID player, String skinHash, boolean slim, String capeHash, boolean capeHidden, String bodyHash) {
        static void encode(AssignPacket m, FriendlyByteBuf buf) {
            buf.writeUUID(m.player);
            buf.writeUtf(m.skinHash, 64);
            buf.writeBoolean(m.slim);
            buf.writeUtf(m.capeHash, 64);
            buf.writeBoolean(m.capeHidden);
            buf.writeUtf(m.bodyHash, 64);
        }

        static AssignPacket decode(FriendlyByteBuf buf) {
            return new AssignPacket(buf.readUUID(), buf.readUtf(64), buf.readBoolean(), buf.readUtf(64), buf.readBoolean(), buf.readUtf(64));
        }

        static void handle(AssignPacket m, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientSkins.onAssign(m)));
            c.setPacketHandled(true);
        }
    }

    // ------------------------------------------------------------------ клиент -> сервер: запрос файла

    public record RequestPacket(String hash) {
        static void encode(RequestPacket m, FriendlyByteBuf buf) {
            buf.writeUtf(m.hash, 64);
        }

        static RequestPacket decode(FriendlyByteBuf buf) {
            return new RequestPacket(buf.readUtf(64));
        }

        static void handle(RequestPacket m, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            ServerPlayer sender = c.getSender();
            if (sender != null) {
                c.enqueueWork(() -> ServerEvents.sendTexture(sender, m.hash));
            }
            c.setPacketHandled(true);
        }
    }

    // ------------------------------------------------------------------ сервер -> клиент: кусок файла

    public record ChunkPacket(String hash, int index, int total, byte[] data) {
        static void encode(ChunkPacket m, FriendlyByteBuf buf) {
            buf.writeUtf(m.hash, 64);
            buf.writeVarInt(m.index);
            buf.writeVarInt(m.total);
            buf.writeByteArray(m.data);
        }

        static ChunkPacket decode(FriendlyByteBuf buf) {
            return new ChunkPacket(buf.readUtf(64), buf.readVarInt(), buf.readVarInt(),
                    buf.readByteArray(ChunkAssembler.CHUNK_SIZE));
        }

        static void handle(ChunkPacket m, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientSkins.onChunk(m)));
            c.setPacketHandled(true);
        }
    }
}
