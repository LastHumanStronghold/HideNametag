package dev.hdskins;

/** Матрица 4x4 (строки), точка = M * (x, y, z, 1). */
final class Xf {
    final double[] m = new double[16];

    static Xf identity() {
        Xf x = new Xf();
        x.m[0] = x.m[5] = x.m[10] = x.m[15] = 1;
        return x;
    }

    static Xf translate(double x, double y, double z) {
        Xf r = identity();
        r.m[3] = x;
        r.m[7] = y;
        r.m[11] = z;
        return r;
    }

    static Xf scale(double x, double y, double z) {
        Xf r = identity();
        r.m[0] = x;
        r.m[5] = y;
        r.m[10] = z;
        return r;
    }

    /** Поворот на deg градусов вокруг оси 0=X, 1=Y, 2=Z (правая система, против часовой при взгляде с + оси). */
    static Xf rotate(int axis, double deg) {
        double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
        Xf r = identity();
        switch (axis) {
            case 0 -> {
                r.m[5] = c;
                r.m[6] = -s;
                r.m[9] = s;
                r.m[10] = c;
            }
            case 1 -> {
                r.m[0] = c;
                r.m[2] = s;
                r.m[8] = -s;
                r.m[10] = c;
            }
            default -> {
                r.m[0] = c;
                r.m[1] = -s;
                r.m[4] = s;
                r.m[5] = c;
            }
        }
        return r;
    }

    /** Поворот кватернионом (x, y, z, w). */
    static Xf quat(double x, double y, double z, double w) {
        double n = Math.sqrt(x * x + y * y + z * z + w * w);
        if (n < 1e-12) return identity();
        x /= n;
        y /= n;
        z /= n;
        w /= n;
        Xf r = identity();
        r.m[0] = 1 - 2 * (y * y + z * z);
        r.m[1] = 2 * (x * y - z * w);
        r.m[2] = 2 * (x * z + y * w);
        r.m[4] = 2 * (x * y + z * w);
        r.m[5] = 1 - 2 * (x * x + z * z);
        r.m[6] = 2 * (y * z - x * w);
        r.m[8] = 2 * (x * z - y * w);
        r.m[9] = 2 * (y * z + x * w);
        r.m[10] = 1 - 2 * (x * x + y * y);
        return r;
    }

    /** Из 16 чисел glTF (по столбцам). */
    static Xf fromColumnMajor(double[] c) {
        Xf r = new Xf();
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) r.m[row * 4 + col] = c[col * 4 + row];
        }
        return r;
    }

    /** Повернуть вокруг точки (ox, oy, oz). */
    static Xf around(Xf rot, double ox, double oy, double oz) {
        return translate(ox, oy, oz).mul(rot).mul(translate(-ox, -oy, -oz));
    }

    /** this * o: сначала применяется o, потом this. */
    Xf mul(Xf o) {
        Xf r = new Xf();
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                double v = 0;
                for (int k = 0; k < 4; k++) v += m[i * 4 + k] * o.m[k * 4 + j];
                r.m[i * 4 + j] = v;
            }
        }
        return r;
    }

    double[] pt(double x, double y, double z) {
        return new double[]{
                m[0] * x + m[1] * y + m[2] * z + m[3],
                m[4] * x + m[5] * y + m[6] * z + m[7],
                m[8] * x + m[9] * y + m[10] * z + m[11]};
    }

    double[] dir(double x, double y, double z) {
        double[] d = {
                m[0] * x + m[1] * y + m[2] * z,
                m[4] * x + m[5] * y + m[6] * z,
                m[8] * x + m[9] * y + m[10] * z};
        double l = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
        if (l > 1e-12) {
            d[0] /= l;
            d[1] /= l;
            d[2] /= l;
        }
        return d;
    }
}
