package dev.hdskins;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.logging.LogUtils;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.slf4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Клиент: загруженные 3D-модели тел и их отрисовка вместо обычного тела игрока. */
@OnlyIn(Dist.CLIENT)
public final class ClientModels {
    private static final Logger LOGGER = LogUtils.getLogger();

    /** Часть модели с одной текстурой. translucent - у текстуры есть полупрозрачные пиксели. */
    public record PartGl(ResourceLocation texture, boolean translucent, float[] pos, float[] uv, float[] nrm) {
    }

    public record Body(List<PartGl> parts) {
    }

    private static final Map<String, Body> BODIES = new ConcurrentHashMap<>();

    private ClientModels() {
    }

    public static boolean has(String hash) {
        return BODIES.containsKey(hash);
    }

    public static Body get(String hash) {
        return BODIES.get(hash);
    }

    /** Главный поток клиента: разбирает полученную модель и регистрирует её текстуры. */
    static void load(String hash, byte[] data) {
        Mesh mesh;
        try {
            mesh = ModelCodec.decode(data);
        } catch (IOException | RuntimeException e) {
            LOGGER.warn("HDSkins: получена повреждённая модель ({}), отбрасываю", e.getMessage());
            return;
        }
        ResourceLocation[] locs = new ResourceLocation[mesh.textures.size()];
        boolean[] translucent = new boolean[locs.length];
        for (int i = 0; i < locs.length; i++) {
            NativeImage img = null;
            try {
                img = NativeImage.read(new ByteArrayInputStream(mesh.textures.get(i)));
                if (img.getWidth() > SkinStore.MAX_RESOLUTION || img.getHeight() > SkinStore.MAX_RESOLUTION) {
                    throw new IOException("texture too large");
                }
                translucent[i] = hasPartialAlpha(img);
                DynamicTexture tex = new DynamicTexture(img);
                img = null;
                locs[i] = new ResourceLocation(HDSkins.MODID, "body/" + hash.substring(0, 32) + "/" + i);
                Minecraft.getInstance().getTextureManager().register(locs[i], tex);
            } catch (IOException | RuntimeException e) {
                LOGGER.warn("HDSkins: не удалось загрузить текстуру модели", e);
                return;
            } finally {
                if (img != null) img.close();
            }
        }
        List<PartGl> parts = new ArrayList<>();
        for (Mesh.Part p : mesh.parts) {
            parts.add(new PartGl(locs[p.texture], translucent[p.texture], p.pos, p.uv, p.nrm));
        }
        BODIES.put(hash, new Body(parts));
    }

    private static boolean hasPartialAlpha(NativeImage img) {
        int stepX = Math.max(1, img.getWidth() / 256), stepY = Math.max(1, img.getHeight() / 256);
        for (int y = 0; y < img.getHeight(); y += stepY) {
            for (int x = 0; x < img.getWidth(); x += stepX) {
                int a = (img.getPixelRGBA(x, y) >>> 24) & 0xFF;
                if (a > 16 && a < 240) return true;
            }
        }
        return false;
    }

    /** Рисует модель на месте игрока (poseStack уже в точке, где стоят ноги игрока). */
    public static void render(Body body, AbstractClientPlayer player, float partialTick, PoseStack ps,
                              MultiBufferSource buffers, int light) {
        float bodyYaw = Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0.0F);
        ps.pushPose();
        // перед модели смотрит в +Z; при угле 0 игрок тоже смотрит в +Z
        ps.mulPose(Axis.YP.rotationDegrees(-bodyYaw));
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        for (PartGl p : body.parts()) {
            RenderType type = p.translucent() ? RenderType.entityTranslucent(p.texture()) : RenderType.entityCutoutNoCull(p.texture());
            VertexConsumer vc = buffers.getBuffer(type);
            int tris = p.pos().length / 9;
            for (int t = 0; t < tris; t++) {
                // формат вершин у Minecraft - четырёхугольники, поэтому последнюю вершину треугольника повторяем
                for (int k = 0; k < 4; k++) {
                    int v = t * 3 + Math.min(k, 2);
                    vc.vertex(m, p.pos()[v * 3], p.pos()[v * 3 + 1], p.pos()[v * 3 + 2])
                            .color(255, 255, 255, 255)
                            .uv(p.uv()[v * 2], p.uv()[v * 2 + 1])
                            .overlayCoords(overlay)
                            .uv2(light)
                            .normal(n, p.nrm()[v * 3], p.nrm()[v * 3 + 1], p.nrm()[v * 3 + 2])
                            .endVertex();
                }
            }
        }
        ps.popPose();
    }
}
