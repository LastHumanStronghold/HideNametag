package dev.hdskins;

import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerAboutToStartEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.network.PacketDistributor;
import org.slf4j.Logger;

import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Серверная часть (работает и на выделенном сервере, и во встроенном). Клиентские классы здесь не трогаем. */
@Mod.EventBusSubscriber(modid = HDSkins.MODID)
public final class ServerEvents {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static volatile SkinStore store;
    private static volatile MinecraftServer server;
    private static ExecutorService scanner;
    private static final AtomicBoolean SCANNING = new AtomicBoolean();
    private static int tickCounter;

    /** Как часто проверять папку skins на новые файлы (в тиках; 100 = 5 секунд). */
    private static final int SCAN_INTERVAL_TICKS = 100;

    private ServerEvents() {
    }

    /** null, если библиотеку не удалось открыть. */
    public static SkinStore store() {
        return store;
    }

    @SubscribeEvent
    public static void onServerAboutToStart(ServerAboutToStartEvent e) {
        server = e.getServer();
        scanner = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "HDSkins-scan");
            t.setDaemon(true);
            return t;
        });
        try {
            store = new SkinStore(FMLPaths.GAMEDIR.get().resolve("hdskins"), LOGGER::warn);
            LOGGER.info("HDSkins: библиотека скинов открыта, скинов: {}", store.list().size());
        } catch (IOException ex) {
            store = null;
            LOGGER.error("HDSkins: не удалось открыть папку hdskins", ex);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        store = null;
        server = null;
        if (scanner != null) {
            scanner.shutdownNow();
            scanner = null;
        }
    }

    /** Автозагрузка: раз в несколько секунд ищем в hdskins/skins новые и изменённые файлы (в фоновом потоке). */
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        SkinStore st = store;
        MinecraftServer srv = server;
        ExecutorService ex = scanner;
        if (st == null || srv == null || ex == null) return;
        if (++tickCounter < SCAN_INTERVAL_TICKS) return;
        tickCounter = 0;
        if (!SCANNING.compareAndSet(false, true)) return;
        ex.execute(() -> {
            try {
                SkinStore.ScanResult r = st.autoScan();
                if (!r.loaded().isEmpty() || !r.failed().isEmpty() || r.modelsChanged()) srv.execute(() -> onScanResult(st, r));
            } catch (RuntimeException ex2) {
                LOGGER.warn("HDSkins: ошибка автозагрузки скинов", ex2);
            } finally {
                SCANNING.set(false);
            }
        });
    }

    /** Главный поток сервера: сообщаем админам и обновляем скин у тех, у кого он стоит. */
    private static void onScanResult(SkinStore st, SkinStore.ScanResult r) {
        MinecraftServer srv = server;
        if (srv == null || st != store) return;
        for (SkinStore.Skin k : r.loaded()) {
            String kind = k.isHd() ? "HD" : "обычный";
            LOGGER.info("HDSkins: автоматически загружен скин {} ({}x{}, {})", k.name(), k.size(), k.size(), kind);
            tellOps(srv, "[HDSkins] Автоматически загружен скин " + k.name() + " (" + k.size() + "x" + k.size() + ", " + kind + ")", ChatFormatting.GREEN);
            for (ServerPlayer p : srv.getPlayerList().getPlayers()) {
                SkinStore.Skin cur = st.skinOf(p.getUUID());
                if (cur != null && cur.name().equals(k.name())) broadcast(p.getUUID());
            }
        }
        for (SkinStore.Model m : r.loadedModels()) {
            LOGGER.info("HDSkins: автоматически загружена 3D-модель {} ({} треугольников)", m.name(), m.triangles());
            tellOps(srv, "[HDSkins] Загружена 3D-модель " + m.name() + " (" + m.triangles() + " треуг.). Выдать: /hdskin body " + m.name() + " <игрок>", ChatFormatting.GREEN);
        }
        for (String name : r.removedModels()) {
            LOGGER.info("HDSkins: 3D-модель {} удалена (файл пропал из папки models)", name);
            tellOps(srv, "[HDSkins] 3D-модель " + name + " убрана: файла больше нет в папке models.", ChatFormatting.YELLOW);
        }
        if (r.modelsChanged()) {
            for (ServerPlayer p : srv.getPlayerList().getPlayers()) broadcast(p.getUUID());
        }
        r.failed().forEach((file, msg) -> {
            LOGGER.warn("HDSkins: не удалось загрузить {}: {}", file, msg);
            tellOps(srv, "[HDSkins] Не удалось загрузить " + file + ": " + msg, ChatFormatting.RED);
        });
    }

    private static void tellOps(MinecraftServer srv, String text, ChatFormatting color) {
        for (ServerPlayer p : srv.getPlayerList().getPlayers()) {
            if (p.hasPermissions(2)) p.sendSystemMessage(Component.literal(text).withStyle(color));
        }
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent e) {
        SkinCommands.register(e.getDispatcher());
    }

    /** Вошедшему игроку - скины всех, кто сейчас на сервере; всем - скин вошедшего. */
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer joined) || store == null) return;
        MinecraftServer server = joined.getServer();
        if (server != null) {
            List<ServerPlayer> online = server.getPlayerList().getPlayers();
            for (ServerPlayer other : online) {
                if (other == joined) continue;
                Net.AssignPacket pkt = assignPacket(other.getUUID());
                if (pkt != null) Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> joined), pkt);
            }
        }
        broadcast(joined.getUUID());
    }

    /** Разослать всем игрокам актуальные скин и плащ (или их отсутствие) для UUID. */
    public static void broadcast(UUID player) {
        SkinStore st = store;
        if (st == null) return;
        Net.CHANNEL.send(PacketDistributor.ALL.noArg(), assignPacket(player) == null
                ? new Net.AssignPacket(player, "", false, "", false, "") // «сбросить всё»
                : assignPacket(player));
    }

    /** null, если у игрока вообще нет ни скина, ни плаща, ни выключенного плаща. */
    private static Net.AssignPacket assignPacket(UUID player) {
        SkinStore st = store;
        SkinStore.Skin s = st.skinOf(player);
        String cape = st.capeOf(player);
        boolean hide = st.capeHidden(player);
        SkinStore.Model body = st.bodyOf(player);
        if (s == null && cape == null && !hide && body == null) return null;
        return new Net.AssignPacket(player, s == null ? "" : s.hash(), s != null && s.slim(),
                cape == null ? "" : cape, hide, body == null ? "" : body.hash());
    }

    /** Отправить игроку файл (скин или плащ) по хэшу (по запросу клиента). Неизвестные хэши игнорируются. */
    public static void sendTexture(ServerPlayer to, String hash) {
        SkinStore st = store;
        if (st == null) return;
        byte[] data = st.readTexture(hash);
        if (data == null) return;
        List<byte[]> parts = ChunkAssembler.split(data);
        for (int i = 0; i < parts.size(); i++) {
            Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> to), new Net.ChunkPacket(hash, i, parts.size(), parts.get(i)));
        }
    }
}
