package dev.hdskins;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Wavefront OBJ (+ .mtl и текстуры рядом). Статичная модель. */
final class ObjLoader {
    private ObjLoader() {
    }

    private static final class Mat {
        String map;
        int argb = 0xFFCCCCCC;
    }

    private static final class Floats {
        float[] a = new float[3 * 1024];
        int n;

        void add(float x, float y, float z) {
            if (n + 3 > a.length) a = Arrays.copyOf(a, a.length * 2);
            a[n++] = x;
            a[n++] = y;
            a[n++] = z;
        }
    }

    static Mesh load(Path file) throws SkinException {
        Path dir = file.toAbsolutePath().getParent();
        try {
            if (Files.size(file) > Imgs.MAX_FILE) throw new SkinException("Файл OBJ слишком большой.");
        } catch (IOException e) {
            throw new SkinException("Не удалось прочитать OBJ: " + e.getMessage());
        }
        Mesh mesh = new Mesh();
        Floats v = new Floats(), vt = new Floats(), vn = new Floats();
        Map<String, Mat> mats = new HashMap<>();
        Map<String, Integer> slots = new HashMap<>();
        String current = null;
        int[] def = {-1};

        try (BufferedReader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            int lineNo = 0;
            while ((line = r.readLine()) != null) {
                lineNo++;
                line = line.trim();
                if (line.isEmpty() || line.charAt(0) == '#') continue;
                String[] t = line.split("\\s+");
                switch (t[0]) {
                    case "v" -> {
                        if (t.length < 4) throw new SkinException("OBJ: строка " + lineNo + ": неполная вершина.");
                        v.add(f(t[1]), f(t[2]), f(t[3]));
                    }
                    case "vt" -> vt.add(f(t[1]), t.length > 2 ? f(t[2]) : 0, 0);
                    case "vn" -> {
                        if (t.length < 4) throw new SkinException("OBJ: строка " + lineNo + ": неполная нормаль.");
                        vn.add(f(t[1]), f(t[2]), f(t[3]));
                    }
                    case "mtllib" -> {
                        for (int k = 1; k < t.length; k++) readMtl(dir, t[k], mats);
                    }
                    case "usemtl" -> current = t.length > 1 ? t[1] : null;
                    case "f" -> {
                        if (t.length < 4) break;
                        int nv = v.n / 3, nt = vt.n / 3, nn = vn.n / 3;
                        int cnt = t.length - 1;
                        int[][] c = new int[cnt][3];
                        for (int k = 0; k < cnt; k++) {
                            String[] p = t[k + 1].split("/", -1);
                            c[k][0] = index(p[0], nv, lineNo);
                            c[k][1] = p.length > 1 && !p[1].isEmpty() ? index(p[1], nt, lineNo) : -1;
                            c[k][2] = p.length > 2 && !p[2].isEmpty() ? index(p[2], nn, lineNo) : -1;
                        }
                        int tex = slot(mesh, dir, file, current, mats, slots, def);
                        for (int k = 1; k + 1 < cnt; k++) {
                            int[][] tri = {c[0], c[k], c[k + 1]};
                            double[][] ps = new double[3][];
                            double[][] ns = new double[3][];
                            boolean hasN = true;
                            float[] uv = new float[6];
                            for (int q = 0; q < 3; q++) {
                                int vi = tri[q][0] * 3;
                                ps[q] = new double[]{v.a[vi], v.a[vi + 1], v.a[vi + 2]};
                                if (tri[q][2] >= 0) {
                                    int ni = tri[q][2] * 3;
                                    double[] nn2 = {vn.a[ni], vn.a[ni + 1], vn.a[ni + 2]};
                                    double l = Math.sqrt(nn2[0] * nn2[0] + nn2[1] * nn2[1] + nn2[2] * nn2[2]);
                                    if (l > 1e-12) {
                                        nn2[0] /= l;
                                        nn2[1] /= l;
                                        nn2[2] /= l;
                                    }
                                    ns[q] = nn2;
                                } else {
                                    hasN = false;
                                }
                                if (tri[q][1] >= 0) {
                                    int ti = tri[q][1] * 3;
                                    uv[q * 2] = vt.a[ti];
                                    uv[q * 2 + 1] = 1f - vt.a[ti + 1]; // в OBJ V считается снизу вверх
                                }
                            }
                            mesh.add(tex, ps[0], ps[1], ps[2], uv, hasN ? ns : null);
                        }
                    }
                    default -> {
                    }
                }
            }
        } catch (IOException e) {
            throw new SkinException("Не удалось прочитать OBJ: " + e.getMessage());
        } catch (NumberFormatException e) {
            throw new SkinException("OBJ: в файле некорректное число.");
        }
        mesh.frontRotation = 180; // обычно экспорт из Blender (перед - в -Z); если иначе, поправьте /hdskin bodyfix
        return mesh.finish();
    }

    private static float f(String s) {
        return Float.parseFloat(s);
    }

    private static int index(String s, int count, int line) throws SkinException {
        int i = Integer.parseInt(s);
        int r = i > 0 ? i - 1 : count + i;
        if (r < 0 || r >= count) throw new SkinException("OBJ: строка " + line + ": индекс вне диапазона.");
        return r;
    }

    private static void readMtl(Path dir, String name, Map<String, Mat> out) throws SkinException {
        Path p = Imgs.findNear(dir, name);
        if (p == null) return;
        Mat cur = null;
        try (BufferedReader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.charAt(0) == '#') continue;
                String[] t = line.split("\\s+");
                switch (t[0].toLowerCase(Locale.ROOT)) {
                    case "newmtl" -> {
                        cur = new Mat();
                        if (t.length > 1) out.put(t[1], cur);
                    }
                    case "kd" -> {
                        if (cur != null && t.length >= 4) {
                            int rr = c(t[1]), gg = c(t[2]), bb = c(t[3]);
                            cur.argb = 0xFF000000 | (rr << 16) | (gg << 8) | bb;
                        }
                    }
                    case "map_kd" -> {
                        if (cur != null && t.length > 1) cur.map = t[t.length - 1];
                    }
                    default -> {
                    }
                }
            }
        } catch (IOException | NumberFormatException e) {
            throw new SkinException("Не удалось прочитать " + name + ".");
        }
    }

    private static int c(String s) {
        return (int) Math.round(Math.max(0, Math.min(1, Double.parseDouble(s))) * 255);
    }

    private static int slot(Mesh mesh, Path dir, Path file, String matName, Map<String, Mat> mats,
                            Map<String, Integer> slots, int[] def) throws SkinException {
        String key = matName == null ? "" : matName;
        Integer s = slots.get(key);
        if (s != null) return s;
        Mat m = matName == null ? null : mats.get(matName);
        byte[] png = null;
        if (m != null && m.map != null) {
            Path img = Imgs.findNear(dir, m.map);
            if (img != null) png = Imgs.toPng(Imgs.readLimited(img));
        }
        if (png == null && m == null) {
            // материала нет: пробуем текстуру с тем же именем, что у модели
            String fn = file.getFileName().toString();
            Path img = Imgs.findImageNear(dir, fn.substring(0, fn.lastIndexOf('.')));
            if (img != null) png = Imgs.toPng(Imgs.readLimited(img));
        }
        if (png == null) png = Imgs.solid(m != null ? m.argb : 0xFFCCCCCC);
        int slot = mesh.addTexture(png);
        slots.put(key, slot);
        return slot;
    }
}
