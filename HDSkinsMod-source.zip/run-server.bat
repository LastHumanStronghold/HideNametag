@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title HDSkins - тестовый сервер

call tools\find-java.bat
if not defined HD_JAVA_OK (
    echo [ОШИБКА] Не найден JDK 17: https://adoptium.net/temurin/releases/?version=17
    pause
    exit /b 1
)
echo Тестовый сервер Forge 1.20.1 с модом (папка run). Это не Mohist, только для проверки.
echo При первом запуске он остановится: откройте run\eula.txt, поставьте eula=true
echo (вы соглашаетесь с лицензией Minecraft) и запустите этот файл снова.
echo.
call gradlew.bat runServer --console=plain
pause
