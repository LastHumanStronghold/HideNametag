@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title HDSkins - сборка

echo ================================================
echo   HDSkins: сборка мода
echo ================================================
echo.

call tools\find-java.bat
if not defined HD_JAVA_OK (
    echo [ОШИБКА] Не найден JDK 17. Нужна именно версия 17: с другими Forge не соберётся.
    echo.
    echo Скачайте Temurin JDK 17: https://adoptium.net/temurin/releases/?version=17
    echo Поставьте и запустите этот файл снова.
    echo.
    pause
    exit /b 1
)
if defined JAVA_HOME echo Java: %JAVA_HOME%
echo.
echo Первая сборка идёт долго (несколько минут): скачивается Forge и Gradle. Нужен интернет.
echo.

call gradlew.bat build --console=plain
if errorlevel 1 (
    echo.
    echo [ОШИБКА] Сборка не удалась. Сохраните текст выше и пришлите его, если нужна помощь.
    echo.
    pause
    exit /b 1
)

set "JAR="
for %%F in (build\libs\hdskins-*.jar) do set "JAR=%%F"
if not defined JAR (
    echo [ОШИБКА] Сборка прошла, но файл мода в build\libs не найден.
    pause
    exit /b 1
)

echo.
echo Проверка файла %JAR%:
powershell -NoProfile -ExecutionPolicy Bypass -File tools\check-jar.ps1 "%JAR%"
if errorlevel 1 (
    echo.
    echo [ОШИБКА] В моде не хватает файлов. Подмена скина работать не будет.
    pause
    exit /b 1
)

if not exist dist mkdir dist
copy /y "%JAR%" dist\ >nul

echo.
echo ================================================
echo   Готово! Мод лежит в папке dist:
for %%F in ("%JAR%") do echo   dist\%%~nxF
echo.
echo   Этот файл положите в mods на сервер и игрокам.
echo ================================================
echo.
start "" explorer "%~dp0dist"
pause
