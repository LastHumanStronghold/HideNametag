@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title HDSkins - тестовый клиент

call tools\find-java.bat
if not defined HD_JAVA_OK (
    echo [ОШИБКА] Не найден JDK 17: https://adoptium.net/temurin/releases/?version=17
    pause
    exit /b 1
)
echo Запускаю клиент Minecraft с модом для проверки (первый запуск долгий)...
call gradlew.bat runClient --console=plain
pause
