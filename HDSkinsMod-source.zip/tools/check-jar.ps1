﻿param([Parameter(Mandatory = $true)][string]$Jar)
# Проверяет, что в собранном моде есть всё нужное для подмены скинов.
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead((Resolve-Path $Jar))
try {
    $names = $zip.Entries | ForEach-Object { $_.FullName }
} finally {
    $zip.Dispose()
}
$need = @('hdskins.refmap.json', 'hdskins.mixins.json', 'META-INF/mods.toml')
$bad = $false
foreach ($n in $need) {
    if ($names -contains $n) {
        Write-Host "  [ok]  $n"
    } else {
        Write-Host "  [!!]  нет файла $n" -ForegroundColor Red
        $bad = $true
    }
}
if ($bad) { exit 1 }
