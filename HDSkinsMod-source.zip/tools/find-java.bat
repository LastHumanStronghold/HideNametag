@echo off
rem Ищет JDK 17 и выставляет JAVA_HOME и HD_JAVA_OK=1. Вызывать: call tools\find-java.bat
set "HD_JAVA_OK="

if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" (
    "%JAVA_HOME%\bin\java.exe" -version 2>&1 | findstr /C:"version \"17." >nul && set "HD_JAVA_OK=1"
)
if defined HD_JAVA_OK goto :eof

java -version 2>&1 | findstr /C:"version \"17." >nul
if not errorlevel 1 (
    set "HD_JAVA_OK=1"
    goto :eof
)

for %%D in ("%ProgramFiles%\Eclipse Adoptium" "%ProgramFiles%\Java" "%ProgramFiles%\Microsoft" "%ProgramFiles%\Zulu" "%ProgramFiles%\BellSoft" "%ProgramFiles%\Amazon Corretto" "%ProgramFiles%\RedHat" "%USERPROFILE%\.jdks") do (
    if exist "%%~D" (
        for /d %%J in ("%%~D\*17*") do (
            if exist "%%~J\bin\java.exe" (
                set "JAVA_HOME=%%~fJ"
                set "HD_JAVA_OK=1"
                goto :eof
            )
        )
    )
)
goto :eof
